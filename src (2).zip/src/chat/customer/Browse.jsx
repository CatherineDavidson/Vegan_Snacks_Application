import React, { useEffect, useState } from "react";
import api from "../api";

export default function Browse() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");

  const load = async () => {
    const { data } = await api.get(`/products${q ? `?q=${encodeURIComponent(q)}` : ""}`);
    setItems(data);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <div>
        <input className="border p-2 rounded mr-2" placeholder="Search..." value={q} onChange={e=>setQ(e.target.value)} />
        <button onClick={load} className="px-3 py-2 bg-indigo-600 text-white rounded">Search</button>
      </div>
      <ul className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {items.map(p => (
          <li key={p.productId} className="p-4 border rounded-xl">{p.name}</li>
        ))}
      </ul>
    </div>
  );
}
