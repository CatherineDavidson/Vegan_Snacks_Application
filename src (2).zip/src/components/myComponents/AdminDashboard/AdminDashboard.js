// import React, { useState } from "react";
// import {
//   BellIcon,
//   CheckBadgeIcon,
//   ClipboardDocumentListIcon,
//   UserGroupIcon,
// } from "@heroicons/react/24/outline";

// export default function AdminDashboard() {
//   const [activeTab, setActiveTab] = useState("requests");

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
//       {/* Navbar */}
//       <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-50">
//         <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
//           <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
//           <div className="flex items-center space-x-6">
//             <button className="relative">
//               <BellIcon className="w-6 h-6 text-gray-600" />
//               <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1.5 rounded-full">
//                 4
//               </span>
//             </button>
//             <img
//               src="https://i.pravatar.cc/40"
//               alt="Admin"
//               className="w-10 h-10 rounded-full border border-gray-300"
//             />
//           </div>
//         </div>
//       </header>

//       {/* Stats */}
//       <section className="max-w-7xl mx-auto px-6 py-6 grid grid-cols-1 md:grid-cols-4 gap-6">
//         <StatCard
//           icon={<UserGroupIcon className="w-8 h-8 text-indigo-600" />}
//           title="Total Vendors"
//           value="120"
//         />
//         <StatCard
//           icon={<ClipboardDocumentListIcon className="w-8 h-8 text-yellow-500" />}
//           title="Pending Requests"
//           value="8"
//         />
//         <StatCard
//           icon={<CheckBadgeIcon className="w-8 h-8 text-green-500" />}
//           title="Docs to Verify"
//           value="15"
//         />
//         <StatCard
//           icon={<BellIcon className="w-8 h-8 text-red-500" />}
//           title="Notifications"
//           value="4"
//         />
//       </section>

//       {/* Main Content */}
//       <main className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-6 pb-10">
//         {/* Left column: Requests + Verification */}
//         <div className="lg:col-span-2 space-y-6">
//           <TabSwitcher activeTab={activeTab} setActiveTab={setActiveTab} />
//           <div className="bg-white rounded-xl shadow p-4">
//             {activeTab === "requests" && (
//               <div>
//                 <h2 className="text-lg font-semibold mb-4">Vendor Requests</h2>
//                 <TablePlaceholder message="List of pending vendor requests" />
//               </div>
//             )}
//             {activeTab === "verify" && (
//               <div>
//                 <h2 className="text-lg font-semibold mb-4">
//                   Document Verification
//                 </h2>
//                 <TablePlaceholder message="Documents awaiting verification" />
//               </div>
//             )}
//           </div>
//         </div>

//         {/* Right column: Notifications */}
//         <div className="space-y-6">
//           <div className="bg-white rounded-xl shadow p-4">
//             <h2 className="text-lg font-semibold mb-4">Notifications</h2>
//             <ul className="space-y-3">
//               {["New vendor registered", "Document uploaded", "Vendor approved"].map(
//                 (note, idx) => (
//                   <li
//                     key={idx}
//                     className="p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition"
//                   >
//                     {note}
//                   </li>
//                 )
//               )}
//             </ul>
//           </div>
//         </div>
//       </main>
//     </div>
//   );
// }

// function StatCard({ icon, title, value }) {
//   return (
//     <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow hover:shadow-md transition flex items-center space-x-4">
//       <div className="p-3 bg-gray-100 rounded-lg">{icon}</div>
//       <div>
//         <p className="text-gray-500 text-sm">{title}</p>
//         <p className="text-2xl font-bold">{value}</p>
//       </div>
//     </div>
//   );
// }

// function TabSwitcher({ activeTab, setActiveTab }) {
//   return (
//     <div className="flex space-x-4 border-b border-gray-200">
//       {[
//         { key: "requests", label: "Requests" },
//         { key: "verify", label: "Verification" },
//       ].map((tab) => (
//         <button
//           key={tab.key}
//           className={`pb-2 px-2 ${
//             activeTab === tab.key
//               ? "border-b-2 border-indigo-600 text-indigo-600 font-medium"
//               : "text-gray-500 hover:text-indigo-600"
//           }`}
//           onClick={() => setActiveTab(tab.key)}
//         >
//           {tab.label}
//         </button>
//       ))}
//     </div>
//   );
// }

// function TablePlaceholder({ message }) {
//   return (
//     <div className="text-center text-gray-500 py-6 border-2 border-dashed border-gray-200 rounded-lg">
//       {message}
//     </div>
//   );
// }
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { Package, Users, TrendingUp, DollarSign, Bell, Search, Filter, Plus, Eye, Edit, Trash2, Star, ShoppingCart, Leaf, AlertCircle, CheckCircle, Clock, ArrowUpRight, ArrowDownRight, MoreHorizontal, Download, Calendar, MapPin } from 'lucide-react';

const AdminDashboard = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('30d');
  const [activeTab, setActiveTab] = useState('overview');
  const [notifications, setNotifications] = useState(5);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Realistic sales data for the last 30 days
  const salesData = [
    { date: '2024-07-17', revenue: 1245, orders: 23, customers: 19 },
    { date: '2024-07-18', revenue: 1890, orders: 31, customers: 28 },
    { date: '2024-07-19', revenue: 2340, orders: 42, customers: 35 },
    { date: '2024-07-20', revenue: 1980, orders: 36, customers: 31 },
    { date: '2024-07-21', revenue: 3450, orders: 58, customers: 47 },
    { date: '2024-07-22', revenue: 4200, orders: 71, customers: 62 },
    { date: '2024-07-23', revenue: 3890, orders: 65, customers: 55 },
    { date: '2024-07-24', revenue: 2180, orders: 38, customers: 32 },
    { date: '2024-07-25', revenue: 2670, orders: 45, customers: 39 },
    { date: '2024-07-26', revenue: 3120, orders: 54, customers: 46 },
    { date: '2024-07-27', revenue: 2890, orders: 49, customers: 42 },
    { date: '2024-07-28', revenue: 4560, orders: 76, customers: 68 },
    { date: '2024-07-29', revenue: 5230, orders: 89, customers: 78 },
    { date: '2024-07-30', revenue: 4780, orders: 82, customers: 71 }
  ];

  // Product categories with realistic data
  const productCategories = [
    { name: 'Protein Bars', value: 28, sales: 3240, color: '#10B981' },
    { name: 'Chips & Crisps', value: 24, sales: 2890, color: '#F59E0B' },
    { name: 'Nuts & Seeds', value: 19, sales: 2156, color: '#EF4444' },
    { name: 'Dried Fruits', value: 16, sales: 1890, color: '#8B5CF6' },
    { name: 'Energy Bites', value: 13, sales: 1234, color: '#06B6D4' }
  ];

  // Recent orders with realistic data
  const recentOrders = [
    { 
      id: 'ORD-2024-3847', 
      customer: 'Sarah Mitchell', 
      email: 'sarah.mitchell@email.com',
      products: ['Organic Kale Chips (2x)', 'Cashew Protein Bar (1x)'], 
      amount: 47.97, 
      status: 'delivered', 
      time: '3 minutes ago',
      location: 'San Francisco, CA'
    },
    { 
      id: 'ORD-2024-3846', 
      customer: 'Michael Chen', 
      email: 'mike.chen@email.com',
      products: ['Mixed Nut Trail Mix (3x)', 'Banana Chips (2x)'], 
      amount: 68.45, 
      status: 'processing', 
      time: '12 minutes ago',
      location: 'Los Angeles, CA'
    },
    { 
      id: 'ORD-2024-3845', 
      customer: 'Emma Rodriguez', 
      email: 'emma.r@email.com',
      products: ['Quinoa Protein Bars (6x)', 'Coconut Strips (1x)'], 
      amount: 89.99, 
      status: 'shipped', 
      time: '1 hour ago',
      location: 'Austin, TX'
    },
    { 
      id: 'ORD-2024-3844', 
      customer: 'James Wilson', 
      email: 'james.wilson@email.com',
      products: ['Spicy Chickpea Snaps (4x)'], 
      amount: 35.96, 
      status: 'pending', 
      time: '2 hours ago',
      location: 'Seattle, WA'
    },
    { 
      id: 'ORD-2024-3843', 
      customer: 'Lisa Thompson', 
      email: 'lisa.t@email.com',
      products: ['Almond Butter Bites (2x)', 'Dark Chocolate Chips (1x)'], 
      amount: 42.50, 
      status: 'delivered', 
      time: '3 hours ago',
      location: 'Denver, CO'
    }
  ];

  // Top products with realistic inventory and performance data
  const topProducts = [
    { 
      id: 'PRD-001',
      name: 'Organic Kale Chips - Sea Salt', 
      sku: 'KLE-SS-150G',
      sales: 1247, 
      revenue: 24940, 
      rating: 4.8, 
      reviews: 324,
      trend: 12.5,
      stock: 156,
      lowStock: false,
      price: 19.99,
      category: 'Chips & Crisps'
    },
    { 
      id: 'PRD-002',
      name: 'Plant Protein Bar - Chocolate Peanut', 
      sku: 'PPB-CP-60G',
      sales: 986, 
      revenue: 34510, 
      rating: 4.9, 
      reviews: 567,
      trend: 8.3,
      stock: 89,
      lowStock: false,
      price: 34.99,
      category: 'Protein Bars'
    },
    { 
      id: 'PRD-003',
      name: 'Raw Cashew Mix - Himalayan Salt', 
      sku: 'RCM-HS-200G',
      sales: 743, 
      revenue: 20061, 
      rating: 4.7, 
      reviews: 189,
      trend: -2.1,
      stock: 23,
      lowStock: true,
      price: 26.99,
      category: 'Nuts & Seeds'
    },
    { 
      id: 'PRD-004',
      name: 'Coconut Date Energy Bites', 
      sku: 'CDE-B-120G',
      sales: 652, 
      revenue: 15648, 
      rating: 4.6, 
      reviews: 145,
      trend: 15.7,
      stock: 201,
      lowStock: false,
      price: 23.99,
      category: 'Energy Bites'
    }
  ];

  // Low stock alerts
  const lowStockProducts = topProducts.filter(p => p.lowStock || p.stock < 50);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'shipped': return <Clock className="w-4 h-4 text-blue-600" />;
      case 'processing': return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'pending': return <AlertCircle className="w-4 h-4 text-orange-600" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'delivered': return 'bg-green-50 text-green-700 border-green-200';
      case 'shipped': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'processing': return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'pending': return 'bg-orange-50 text-orange-700 border-orange-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const totalRevenue = salesData.reduce((sum, day) => sum + day.revenue, 0);
  const totalOrders = salesData.reduce((sum, day) => sum + day.orders, 0);
  const avgOrderValue = totalRevenue / totalOrders;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">GreenBites Admin</h1>
                  <p className="text-sm text-gray-500">Vegan Snacks Management</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right text-sm text-gray-500">
                <p>{currentTime.toLocaleDateString()}</p>
                <p>{currentTime.toLocaleTimeString()}</p>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input 
                  type="text" 
                  placeholder="Search orders, products..." 
                  className="pl-10 pr-4 py-2 w-80 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <button className="relative p-2 text-gray-400 hover:text-gray-600">
                <Bell className="w-6 h-6" />
                {notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {notifications}
                  </span>
                )}
              </button>
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">A</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen">
          <nav className="p-4 space-y-1">
            {[
              { id: 'overview', label: 'Dashboard Overview', icon: TrendingUp },
              { id: 'products', label: 'Products', icon: Package, badge: lowStockProducts.length },
              { id: 'orders', label: 'Orders', icon: ShoppingCart, badge: recentOrders.filter(o => o.status === 'pending').length },
              { id: 'customers', label: 'Customers', icon: Users },
              { id: 'analytics', label: 'Analytics', icon: BarChart },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-left rounded-lg transition-colors ${
                  activeTab === item.id 
                    ? 'bg-green-50 text-green-700 border border-green-200' 
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </div>
                {item.badge > 0 && (
                  <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === 'overview' && (
            <>
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Total Revenue (30d)</p>
                      <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRevenue)}</p>
                      <div className="flex items-center mt-2">
                        <ArrowUpRight className="w-4 h-4 text-green-500" />
                        <span className="text-sm text-green-500 font-medium">+18.2%</span>
                      </div>
                    </div>
                    <DollarSign className="w-8 h-8 text-green-600" />
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Total Orders</p>
                      <p className="text-2xl font-bold text-gray-900">{totalOrders.toLocaleString()}</p>
                      <div className="flex items-center mt-2">
                        <ArrowUpRight className="w-4 h-4 text-green-500" />
                        <span className="text-sm text-green-500 font-medium">+12.5%</span>
                      </div>
                    </div>
                    <ShoppingCart className="w-8 h-8 text-blue-600" />
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Avg Order Value</p>
                      <p className="text-2xl font-bold text-gray-900">{formatCurrency(avgOrderValue)}</p>
                      <div className="flex items-center mt-2">
                        <ArrowUpRight className="w-4 h-4 text-green-500" />
                        <span className="text-sm text-green-500 font-medium">+5.1%</span>
                      </div>
                    </div>
                    <TrendingUp className="w-8 h-8 text-purple-600" />
                  </div>
                </div>

                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Active Products</p>
                      <p className="text-2xl font-bold text-gray-900">{topProducts.length}</p>
                      <div className="flex items-center mt-2">
                        <ArrowDownRight className="w-4 h-4 text-red-500" />
                        <span className="text-sm text-red-500 font-medium">-2.3%</span>
                      </div>
                    </div>
                    <Package className="w-8 h-8 text-orange-600" />
                  </div>
                </div>
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Revenue Chart */}
                <div className="lg:col-span-2 bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Revenue Trend</h3>
                    <select 
                      value={selectedPeriod}
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      className="px-3 py-1 border border-gray-300 rounded-md text-sm"
                    >
                      <option value="7d">Last 7 days</option>
                      <option value="30d">Last 30 days</option>
                      <option value="90d">Last 90 days</option>
                    </select>
                  </div>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={salesData.slice(-14)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis 
                        dataKey="date" 
                        stroke="#64748b"
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      />
                      <YAxis 
                        stroke="#64748b"
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                      />
                      <Tooltip 
                        formatter={(value, name) => [formatCurrency(value), 'Revenue']}
                        labelFormatter={(label) => new Date(label).toLocaleDateString()}
                        contentStyle={{
                          backgroundColor: 'white',
                          border: '1px solid #e2e8f0',
                          borderRadius: '8px',
                          fontSize: '14px'
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="revenue" 
                        stroke="#059669" 
                        fill="url(#colorRevenue)"
                        strokeWidth={2}
                      />
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#059669" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Product Categories */}
                <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Product Categories</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={productCategories}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {productCategories.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Market Share']} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2 mt-4">
                    {productCategories.map((category, index) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: category.color }}
                          ></div>
                          <span className="text-gray-600">{category.name}</span>
                        </div>
                        <span className="font-medium text-gray-900">{category.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recent Orders & Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Orders */}
                <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">Recent Orders</h3>
                    <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                      View All
                    </button>
                  </div>
                  <div className="p-0">
                    {recentOrders.map((order, index) => (
                      <div key={index} className="px-6 py-4 border-b border-gray-100 last:border-b-0">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <span className="font-medium text-gray-900">{order.id}</span>
                              <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs border ${getStatusColor(order.status)}`}>
                                {getStatusIcon(order.status)}
                                <span className="capitalize">{order.status}</span>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600">{order.customer}</p>
                            <p className="text-xs text-gray-500">{order.products.join(', ')}</p>
                            <div className="flex items-center space-x-4 mt-2">
                              <span className="text-xs text-gray-500 flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {order.location}
                              </span>
                              <span className="text-xs text-gray-500">{order.time}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-gray-900">{formatCurrency(order.amount)}</p>
                            <button className="text-gray-400 hover:text-gray-600 mt-1">
                              <MoreHorizontal className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Alerts & Low Stock */}
                <div className="space-y-6">
                  {/* Low Stock Alert */}
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div className="px-4 py-3 border-b border-gray-200">
                      <h4 className="text-sm font-semibold text-gray-900 flex items-center">
                        <AlertCircle className="w-4 h-4 mr-2 text-orange-500" />
                        Low Stock Alert
                      </h4>
                    </div>
                    <div className="p-4 space-y-3">
                      {lowStockProducts.map((product, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900 truncate">{product.name}</p>
                            <p className="text-xs text-gray-500">Stock: {product.stock}</p>
                          </div>
                          <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full">
                            Low
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div className="px-4 py-3 border-b border-gray-200">
                      <h4 className="text-sm font-semibold text-gray-900">Quick Actions</h4>
                    </div>
                    <div className="p-4 space-y-2">
                      <button className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-sm bg-green-50 text-green-700 rounded-lg hover:bg-green-100">
                        <Plus className="w-4 h-4" />
                        <span>Add Product</span>
                      </button>
                      <button className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-sm bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100">
                        <Download className="w-4 h-4" />
                        <span>Export Data</span>
                      </button>
                      <button className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-sm bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100">
                        <Calendar className="w-4 h-4" />
                        <span>Schedule Report</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Products Management</h2>
                <div className="flex space-x-3">
                  <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Filter className="w-4 h-4" />
                    <span>Filter</span>
                  </button>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    <Plus className="w-4 h-4" />
                    <span>Add Product</span>
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">Product Inventory</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {topProducts.map((product) => (
                        <tr key={product.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                <Package className="w-5 h-5 text-green-600" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{product.name}</p>
                                </div>
                                </div>
                                </td>
                                </tr>))}
                                </tbody>
                                </table>
                                </div>
                                </div>
                                </div>)}
                                </main></div></div>)}
export default AdminDashboard;