import React, { useEffect, useState } from "react";
import api from "../api";

export default function VendorProducts({ vendorId }) {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: "", description: "" });

  const load = async () => {
    const { data } = await api.get(`/vendor/products?vendorId=${vendorId}`);
    setProducts(data);
  };

  useEffect(() => { load(); }, [vendorId]);

  const create = async () => {
    await api.post("/vendor/products", { ...form, vendorId });
    setForm({ name: "", description: "" });
    load();
  };

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-xl shadow">
        <h3 className="font-semibold mb-2">Create Product</h3>
        <input className="border p-2 mr-2 rounded" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input className="border p-2 mr-2 rounded" placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
        <button onClick={create} className="px-3 py-2 bg-emerald-600 text-white rounded">Save</button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow">
        <h3 className="font-semibold mb-2">Your Products</h3>
        <ul className="divide-y">
          {products.map(p => (
            <li key={p.productId} className="py-2 flex justify-between">
              <span>{p.name} <em className="text-xs text-gray-500">({p.status})</em></span>
              <a href={`#product-${p.productId}`} className="text-indigo-600">Manage</a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
