// import React, { useEffect, useState } from 'react';
// import { X, Menu, Zap, Star, Users, Shield, Sparkles, MessageCircle, ChevronRight, ArrowRight, Play, Sun, Moon } from 'lucide-react';

// const Home = () => {
//   const [isDarkMode, setIsDarkMode] = useState(true);
//   const [categories] = useState([
//     { id: 1, name: "Power Crunch", description: "Energy-packed crispy snacks for active lifestyles", gradient: "from-purple-500 to-pink-500" },
//     { id: 2, name: "Sweet Escape", description: "Guilt-free desserts that satisfy your sweet tooth", gradient: "from-orange-500 to-red-500" },
//     { id: 3, name: "Protein Boost", description: "High-protein snacks for muscle building and recovery", gradient: "from-blue-500 to-cyan-500" }
//   ]);
  
//   const [testimonials] = useState([
//     { name: "Alex Thompson", role: "Nutritionist", content: "The quality and taste exceeded all my expectations. Perfect for my clients!", rating: 5, avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face" },
//     { name: "Maya Patel", role: "Yoga Instructor", content: "These snacks give me sustained energy throughout my classes. Absolutely love them!", rating: 5, avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face" }
//   ]);
  
//   const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });
//   const [successMessage, setSuccessMessage] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [scrollY, setScrollY] = useState(0);

//   useEffect(() => {
//     const handleScroll = () => setScrollY(window.scrollY);
//     window.addEventListener('scroll', handleScroll);
//     return () => window.removeEventListener('scroll', handleScroll);
//   }, []);

//   const handleChange = (e) => {
//     setContactForm({ ...contactForm, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setSuccessMessage('');
//     setErrorMessage('');
//     setTimeout(() => {
//       setSuccessMessage('Message sent successfully!');
//       setContactForm({ name: '', email: '', message: '' });
//     }, 1000);
//   };

//   const scrollToSection = (id) => {
//     document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
//     setIsMenuOpen(false);
//   };

//   const toggleTheme = () => setIsDarkMode(!isDarkMode);
//   const navigateToLogin = () => console.log('Navigate to login');
//   const navigateToRegister = () => console.log('Navigate to register');

//   // Theme classes
//   const themeClasses = {
//     bg: {
//       primary: isDarkMode ? 'bg-slate-900' : 'bg-gray-50',
//       secondary: isDarkMode ? 'bg-slate-800' : 'bg-white',
//       tertiary: isDarkMode ? 'bg-slate-700' : 'bg-gray-100',
//       accent: isDarkMode ? 'bg-slate-800/50' : 'bg-gray-100/50'
//     },
//     text: {
//       primary: isDarkMode ? 'text-white' : 'text-gray-900',
//       secondary: isDarkMode ? 'text-slate-300' : 'text-gray-700',
//       muted: isDarkMode ? 'text-slate-400' : 'text-gray-500'
//     },
//     border: {
//       primary: isDarkMode ? 'border-slate-700' : 'border-gray-200',
//       secondary: isDarkMode ? 'border-slate-600' : 'border-gray-300'
//     },
//     navbar: {
//       bg: isDarkMode ? 'bg-slate-900/90' : 'bg-white/90'
//     },
//     button: {
//       theme: isDarkMode 
//         ? 'bg-slate-800 text-yellow-400 hover:bg-slate-700' 
//         : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
//     },
//     mobile: {
//       bg: isDarkMode ? 'bg-slate-900/95' : 'bg-white/95'
//     },
//     heroBlobs: {
//       violet: isDarkMode ? 'from-violet-500/20 to-purple-500/20' : 'from-violet-500/10 to-purple-500/10',
//       cyan: isDarkMode ? 'from-cyan-500/20 to-blue-500/20' : 'from-cyan-500/10 to-blue-500/10',
//       pink: isDarkMode ? 'from-pink-500/10 to-orange-500/10' : 'from-pink-500/5 to-orange-500/5'
//     },
//     badge: {
//       bg: isDarkMode ? 'from-violet-500/20 to-purple-500/20' : 'from-violet-500/10 to-purple-500/10',
//       border: isDarkMode ? 'border-violet-500/30' : 'border-violet-500/20',
//       text: isDarkMode ? 'text-violet-300' : 'text-violet-700'
//     },
//     input: {
//       placeholder: isDarkMode ? 'placeholder-slate-400' : 'placeholder-gray-500'
//     }
//   };

//   return (
//     <div className={`min-h-screen transition-colors duration-300 ${themeClasses.bg.primary} ${themeClasses.text.primary}`}>
//       {/* Floating Navbar */}
//       <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
//         scrollY > 50 
//           ? `${themeClasses.navbar.bg} backdrop-blur-xl shadow-2xl ${themeClasses.border.primary}` 
//           : 'bg-transparent'
//       }`}>
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="flex items-center justify-between h-16">
//             {/* Logo */}
//             <div 
//               className="text-3xl font-bold bg-gradient-to-r from-violet-500 to-purple-500 bg-clip-text text-transparent cursor-pointer transform hover:scale-105 transition-transform"
//               onClick={() => scrollToSection('hero')}
//             >
//               Fresh<span className="text-cyan-400">Bites</span>
//             </div>

//             {/* Desktop Navigation */}
//             <div className="hidden md:flex items-center space-x-8">
//               {/* Theme Toggle */}
//               <button 
//                 onClick={toggleTheme}
//                 className={`p-2 rounded-full transition-all duration-300 ${themeClasses.button.theme}`}
//                 title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
//               >
//                 {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
//               </button>
              
//               <button onClick={() => scrollToSection('features')} className={`${themeClasses.text.secondary} hover:text-cyan-400 font-medium transition-colors`}>
//                 Features
//               </button>
//               <button onClick={() => scrollToSection('categories')} className={`${themeClasses.text.secondary} hover:text-cyan-400 font-medium transition-colors`}>
//                 Categories
//               </button>
//               <button onClick={() => scrollToSection('testimonials')} className={`${themeClasses.text.secondary} hover:text-cyan-400 font-medium transition-colors`}>
//                 Reviews
//               </button>
//               <button onClick={() => scrollToSection('contact')} className={`${themeClasses.text.secondary} hover:text-cyan-400 font-medium transition-colors`}>
//                 Contact
//               </button>
//               <button 
//                 onClick={navigateToLogin}
//                 className={`px-4 py-2 text-cyan-400 border border-cyan-400 rounded-full hover:bg-cyan-400 transition-all duration-300 ${isDarkMode ? 'hover:text-slate-900' : 'hover:text-white'}`}
//               >
//                 Login
//               </button>
//               <button 
//                 onClick={navigateToRegister}
//                 className="px-6 py-2 bg-gradient-to-r from-violet-500 to-purple-500 text-white rounded-full hover:opacity-90 transform hover:scale-105 transition-all duration-300 shadow-lg"
//               >
//                 Register
//               </button>
//             </div>

//             {/* Mobile menu button */}
//             <div className="md:hidden flex items-center space-x-2">
//               {/* Mobile Theme Toggle */}
//               <button 
//                 onClick={toggleTheme}
//                 className={`p-2 rounded-full transition-all duration-300 ${themeClasses.button.theme}`}
//               >
//                 {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
//               </button>
              
//               <button
//                 onClick={() => setIsMenuOpen(!isMenuOpen)}
//                 className={`p-2 ${themeClasses.text.secondary} hover:text-cyan-400 transition-colors`}
//               >
//                 {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
//               </button>
//             </div>
//           </div>
//         </div>

//         {/* Mobile Navigation */}
//         {isMenuOpen && (
//           <div className={`md:hidden ${themeClasses.mobile.bg} backdrop-blur-xl border-t ${themeClasses.border.primary}`}>
//             <div className="px-4 pt-2 pb-3 space-y-1">
//               <button onClick={() => scrollToSection('features')} className={`block w-full text-left px-3 py-2 ${themeClasses.text.secondary} hover:text-cyan-400`}>Features</button>
//               <button onClick={() => scrollToSection('categories')} className={`block w-full text-left px-3 py-2 ${themeClasses.text.secondary} hover:text-cyan-400`}>Categories</button>
//               <button onClick={() => scrollToSection('testimonials')} className={`block w-full text-left px-3 py-2 ${themeClasses.text.secondary} hover:text-cyan-400`}>Reviews</button>
//               <button onClick={() => scrollToSection('contact')} className={`block w-full text-left px-3 py-2 ${themeClasses.text.secondary} hover:text-cyan-400`}>Contact</button>
//               <div className="pt-4 space-y-2">
//                 <button onClick={navigateToLogin} className="block w-full px-3 py-2 text-cyan-400 border border-cyan-400 rounded-lg">Login</button>
//                 <button onClick={navigateToRegister} className="block w-full px-3 py-2 bg-gradient-to-r from-violet-500 to-purple-500 text-white rounded-lg">Register</button>
//               </div>
//             </div>
//           </div>
//         )}
//       </nav>

//       {/* Hero Section */}
//       <section id="hero" className="relative pt-24 pb-20 px-4 overflow-hidden">
//         {/* Animated Background */}
//         <div className="absolute inset-0">
//           <div className={`absolute top-20 left-10 w-96 h-96 bg-gradient-to-r ${themeClasses.heroBlobs.violet} rounded-full blur-3xl animate-pulse`}></div>
//           <div className={`absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-r ${themeClasses.heroBlobs.cyan} rounded-full blur-3xl animate-pulse delay-1000`}></div>
//           <div className={`absolute top-1/2 left-1/2 w-72 h-72 bg-gradient-to-r ${themeClasses.heroBlobs.pink} rounded-full blur-3xl animate-pulse delay-2000`}></div>
//         </div>
        
//         <div className="relative max-w-7xl mx-auto text-center">
//           <div className={`inline-flex items-center px-6 py-3 bg-gradient-to-r ${themeClasses.badge.bg} border ${themeClasses.badge.border} ${themeClasses.badge.text} rounded-full text-sm font-medium mb-8 backdrop-blur-sm`}>
//             <Sparkles className="w-4 h-4 mr-2" />
//             Premium Vegan Snacks • Now Available
//           </div>
          
//           <h1 className="text-6xl md:text-8xl font-bold mb-8 leading-tight">
//             <span className="bg-gradient-to-r from-violet-400 via-violet-500 to-cyan-400 bg-clip-text text-transparent">
//               Snacking
//             </span>
//             <br />
//             <span className={themeClasses.text.primary}>Reimagined</span>
//           </h1>
          
//           <p className={`text-xl md:text-2xl ${themeClasses.text.secondary} mb-12 max-w-4xl mx-auto leading-relaxed`}>
//             Experience the future of healthy eating with our scientifically crafted, 
//             plant-based snacks that fuel your ambitions and satisfy your cravings.
//           </p>
          
//           <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-20">
//             <button 
//               onClick={() => scrollToSection('categories')}
//               className="group px-8 py-4 bg-gradient-to-r from-violet-500 to-purple-500 text-white text-lg font-semibold rounded-full hover:opacity-90 transform hover:scale-105 transition-all duration-300 shadow-xl flex items-center"
//             >
//               Start Your Journey
//               <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
//             </button>
//             <button 
//               onClick={() => scrollToSection('features')}
//               className={`group flex items-center px-8 py-4 border-2 border-cyan-400 text-cyan-400 text-lg font-semibold rounded-full hover:bg-cyan-400 transition-all duration-300 ${isDarkMode ? 'hover:text-slate-900' : 'hover:text-white'}`}
//             >
//               <Play className="w-5 h-5 mr-2" />
//               Watch Demo
//             </button>
//           </div>

//           {/* Stats Grid */}
//           <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-5xl mx-auto">
//             <div className={`${themeClasses.bg.secondary} backdrop-blur-sm rounded-2xl p-6 border ${themeClasses.border.primary}`}>
//               <div className="text-4xl font-bold bg-gradient-to-r from-violet-400 to-violet-500 bg-clip-text text-transparent mb-2">100K+</div>
//               <div className={themeClasses.text.muted}>Happy Customers</div>
//             </div>
//             <div className={`${themeClasses.bg.secondary} backdrop-blur-sm rounded-2xl p-6 border ${themeClasses.border.primary}`}>
//               <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-cyan-500 bg-clip-text text-transparent mb-2">500+</div>
//               <div className={themeClasses.text.muted}>Premium Products</div>
//             </div>
//             <div className={`${themeClasses.bg.secondary} backdrop-blur-sm rounded-2xl p-6 border ${themeClasses.border.primary}`}>
//               <div className="text-4xl font-bold bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent mb-2">4.9★</div>
//               <div className={themeClasses.text.muted}>Average Rating</div>
//             </div>
//             <div className={`${themeClasses.bg.secondary} backdrop-blur-sm rounded-2xl p-6 border ${themeClasses.border.primary}`}>
//               <div className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent mb-2">50+</div>
//               <div className={themeClasses.text.muted}>Countries</div>
//             </div>
//           </div>
//         </div>
//       </section>

// {/* Features Section */}
// <section id="features" className={`py-24 px-4 ${themeClasses.bg.accent}`}>
//   <div className="max-w-7xl mx-auto">
//     <div className="text-center mb-20">
//       <h2 className="text-5xl md:text-6xl font-bold mb-6">
//         Why <span className="bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">FreshBites</span>?
//       </h2>
//       <p className={`text-xl ${themeClasses.text.secondary} max-w-2xl mx-auto leading-relaxed`}>
//         Ready to transform your snacking experience? We're here to help you every step of the way.
//       </p>
//     </div>

//     <div className={`${themeClasses.bg.secondary} rounded-3xl p-8 md:p-12 border ${themeClasses.border.primary} shadow-2xl`}>
//       <div className="space-y-6">
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//           <div>
//             <label className={`block ${themeClasses.text.secondary} font-medium mb-3`}>Your Name</label>
//             <input
//               name="name"
//               value={contactForm.name}
//               onChange={handleChange}
//               type="text"
//               className={`w-full px-4 py-4 ${themeClasses.bg.tertiary} border ${themeClasses.border.secondary} rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent transition-all duration-300 ${themeClasses.text.primary} ${themeClasses.input.placeholder}`}
//               placeholder="Enter your name"
//             />
//           </div>
//           <div>
//             <label className={`block ${themeClasses.text.secondary} max-w-3xl mx-auto leading-relaxed`}>
//               We've revolutionized snacking with cutting-edge nutrition science and sustainable practices.
//             </label>
//           </div>
//         </div>

//         <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-8">
//           {/* Card 1 */}
//           <div className={`group relative ${themeClasses.bg.secondary} rounded-3xl p-8 border ${themeClasses.border.primary} hover:border-violet-500 transition-all duration-300 transform hover:-translate-y-2 overflow-hidden`}>
//             <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-violet-500/20 to-purple-500/20 rounded-full transform translate-x-16 -translate-y-16 group-hover:scale-150 transition-transform duration-500"></div>
//             <div className="relative z-10">
//               <div className="w-16 h-16 bg-gradient-to-r from-violet-500 to-purple-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
//                 <Zap className="w-8 h-8 text-white" />
//               </div>
//               <h3 className={`text-xl font-bold ${themeClasses.text.primary} mb-4`}>Supercharged Nutrition</h3>
//               <p className={`${themeClasses.text.secondary} leading-relaxed`}>
//                 Packed with superfoods, adaptogens, and essential nutrients for peak performance.
//               </p>
//             </div>
//           </div>

//           {/* Card 2 */}
//           <div className={`group relative ${themeClasses.bg.secondary} rounded-3xl p-8 border ${themeClasses.border.primary} hover:border-cyan-500 transition-all duration-300 transform hover:-translate-y-2 overflow-hidden`}>
//             <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-full transform translate-x-16 -translate-y-16 group-hover:scale-150 transition-transform duration-500"></div>
//             <div className="relative z-10">
//               <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
//                 <Shield className="w-8 h-8 text-white" />
//               </div>
//               <h3 className={`text-xl font-bold ${themeClasses.text.primary} mb-4`}>Premium Quality</h3>
//               <p className={`${themeClasses.text.secondary} leading-relaxed`}>
//                 Rigorously tested, organic ingredients sourced from the world's best farms.
//               </p>
//             </div>
//           </div>

//           {/* Card 3 */}
//           <div className={`group relative ${themeClasses.bg.secondary} rounded-3xl p-8 border ${themeClasses.border.primary} hover:border-pink-500 transition-all duration-300 transform hover:-translate-y-2 overflow-hidden`}>
//             <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full transform translate-x-16 -translate-y-16 group-hover:scale-150 transition-transform duration-500"></div>
//             <div className="relative z-10">
//               <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-orange-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
//                 <Users className="w-8 h-8 text-white" />
//               </div>
//               <h3 className={`text-xl font-bold ${themeClasses.text.primary} mb-4`}>Community Driven</h3>
//               <p className={`${themeClasses.text.secondary} leading-relaxed`}>
//                 Join thousands of health enthusiasts transforming their lifestyle with us.
//               </p>
//             </div>
//           </div>

//           {/* Card 4 */}
//           <div className={`group relative ${themeClasses.bg.secondary} rounded-3xl p-8 border ${themeClasses.border.primary} hover:border-green-500 transition-all duration-300 transform hover:-translate-y-2 overflow-hidden`}>
//             <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-full transform translate-x-16 -translate-y-16 group-hover:scale-150 transition-transform duration-500"></div>
//             <div className="relative z-10">
//               <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
//                 <MessageCircle className="w-8 h-8 text-white" />
//               </div>
//               <h3 className={`text-xl font-bold ${themeClasses.text.primary} mb-4`}>Expert Support</h3>
//               <p className={`${themeClasses.text.secondary} leading-relaxed`}>
//                 24/7 nutritionist support and personalized recommendations for your goals.
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
// </section>

//       {/* Footer */}
//       {/* <footer className={`bg-${colors.bg.accent} border-t border-${colors.border.primary} py-16 px-4`}>
//         <div className="max-w-7xl mx-auto text-center">
//           <div className={`text-4xl font-bold bg-gradient-to-r from-${colors.primary.light} to-${colors.secondary.light} bg-clip-text text-transparent mb-6`}>
//             Fresh<span className={`text-purple-400`}>Bites</span>
//           </div>
//           <p className={`text-${colors.text.muted} mb-8 text-lg max-w-2xl mx-auto`}>
//             Revolutionizing nutrition, one premium snack at a time. Join the movement towards better health.
//           </p>
//           <div className={`border-t border-${colors.border.primary} pt-8`}>
//             <p className={`text-${colors.text.muted}`}>
//               © 2024 FreshBites. All rights reserved. Crafted with ⚡ for peak performance.
//             </p>
//           </div>
//         </div>
//       </footer> */}
//     </div>
//   );
// };

// export default Home;

import React, { useState, useEffect, useRef } from "react";

const roles = [
  { label: "Customer", value: "CUSTOMER", icon: "👤" },
  { label: "Vendor", value: "VENDOR", icon: "🛍️" },
  { label: "Product Manager", value: "PRODUCT_MANAGER", icon: "📦" },
];

const Register = () => {
  const [currentStep, setCurrentStep] = useState(1);
  
  // Basic registration data
  const [formData, setFormData] = useState({
    userName: '',
    email: '',
    password: '',
    role: ''
  });

  // Vendor specific data
  const [vendorData, setVendorData] = useState({
    companyName: '',
    businessEmail: '',
    primaryContactNumber: '',
    businessDescription: '',
    businessRegistrationNumber: '',
    businessLicenseNumber: '',
    taxId: '',
    establishedYear: '',
    websiteUrl: '',
    streetAddress1: '',
    streetAddress2: '',
    city: '',
    state: '',
    postalCode: ''
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const dropdownRef = useRef();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleVendorChange = (e) => {
    setVendorData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleRoleSelect = (role) => {
    setFormData(prev => ({ ...prev, role: role.value }));
    setIsDropdownOpen(false);
  };

  const handleBasicSubmit = async (e) => {
    e.preventDefault();
    setError("");
    
    // Validate required fields
    if (!formData.userName || !formData.email || !formData.password || !formData.role) {
      setError("Please fill in all required fields");
      return;
    }

    // If vendor is selected, go to step 2
    if (formData.role === 'VENDOR') {
      setCurrentStep(2);
      return;
    }

    // For non-vendor roles, proceed with registration
    await submitRegistration();
  };

  const handleVendorSubmit = async (e) => {
    e.preventDefault();
    
    // Validate required vendor fields
    const requiredFields = ['companyName', 'businessEmail', 'primaryContactNumber', 'streetAddress1', 'city', 'state', 'postalCode'];
    const missingFields = requiredFields.filter(field => !vendorData[field]);
    
    if (missingFields.length > 0) {
      setError("Please fill in all required vendor fields");
      return;
    }

    await submitRegistration();
  };

  const submitRegistration = async () => {
    setIsSubmitting(true);
    setError("");
    setSuccess("");

    try {
      // Simulate API call - replace with your actual registerUser service
      const registrationData = {
        ...formData,
        ...(formData.role === 'VENDOR' ? vendorData : {})
      };

      // Log the data that would be sent to your backend
      console.log('Registration Data:', registrationData);
      
      // Simulate success
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSuccess(`Registration successful! Welcome ${formData.userName}!`);

      // In real implementation, you would call:
      // const response = await registerUser(registrationData);
      
    } catch (err) {
      setError(err.message || "Registration failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const goBack = () => {
    setCurrentStep(1);
  };

  const goHome = () => {
    setCurrentStep(1);
    setFormData({ userName: '', email: '', password: '', role: '' });
    setVendorData({
      companyName: '', businessEmail: '', primaryContactNumber: '',
      businessDescription: '', businessRegistrationNumber: '', businessLicenseNumber: '',
      taxId: '', establishedYear: '', websiteUrl: '', streetAddress1: '',
      streetAddress2: '', city: '', state: '', postalCode: ''
    });
    setError('');
    setSuccess('');
  };

  // Popup Component
  const PopUp = ({ message, type, onClose }) => {
    if (!message) return null;

    return (
      <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm ${
        type === 'success' ? 'bg-green-100 border-green-400 text-green-700' : 'bg-red-100 border-red-400 text-red-700'
      }`}>
        <div className="flex justify-between items-center">
          <span>{message}</span>
          <button onClick={onClose} className="ml-2 font-bold">×</button>
        </div>
      </div>
    );
  };

  // Step 1: Basic Registration 
  const renderBasicForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-[#3E5F44] text-base font-semibold mb-1">Username</label>
        <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
          <span className="px-3 text-[#4A9782]">👤</span>
          <input
            type="text"
            name="userName"
            value={formData.userName}
            onChange={handleChange}
            required
            placeholder="Choose a username"
            className="w-full p-3 bg-transparent focus:outline-none"
          />
        </div>
      </div>

      <div>
        <label className="block text-[#3E5F44] text-base font-semibold mb-1">Email</label>
        <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
          <span className="px-3 text-[#4A9782]">✉️</span>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            placeholder="Enter your email"
            className="w-full p-3 bg-transparent focus:outline-none"
          />
        </div>
      </div>

      <div>
        <label className="block text-[#3E5F44] text-base font-semibold mb-1">Password</label>
        <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
          <span className="px-3 text-[#4A9782]">🔒</span>
          <input
            type={showPassword ? "text" : "password"}
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
            placeholder="Create a password"
            className="w-full p-3 bg-transparent focus:outline-none"
          />
          <button
            type="button"
            onClick={() => setShowPassword(prev => !prev)}
            className="px-3 text-[#4A9782] focus:outline-none"
          >
            {showPassword ? '🙈' : '👁️'}
          </button>
        </div>
      </div>

      <div ref={dropdownRef} className="relative">
        <label className="block text-base font-semibold text-[#3E5F44] mb-1">Role</label>
        <button
          type="button"
          onClick={() => setIsDropdownOpen(prev => !prev)}
          className="w-full flex justify-between items-center px-4 py-2 bg-[#E8FFD7] border border-[#A3DC9A] rounded-lg shadow-sm hover:shadow-md transition focus:outline-none"
        >
          <span className="text-[#3E5F44] font-medium">
            {formData.role
              ? roles.find(r => r.value === formData.role).label
              : "-- Select a Role --"}
          </span>
          <span className="text-[#4A9782]">▼</span>
        </button>

        {isDropdownOpen && (
          <ul className="absolute z-10 mt-1 w-full bg-[#E8FFD7] border border-[#A3DC9A] rounded-lg shadow-md max-h-48 overflow-y-auto">
            {roles.map((role) => (
              <li
                key={role.value}
                onClick={() => handleRoleSelect(role)}
                className="flex justify-between items-center px-4 py-2 cursor-pointer hover:bg-[#D0F1C4] hover:shadow-md transition border-b border-[#D0F1C4] last:border-b-0"
              >
                <span className="text-[#3E5F44]">{role.icon} {role.label}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <button
        type="button"
        onClick={handleBasicSubmit}
        className="w-full py-3 bg-[#4A9782] text-white font-semibold rounded-lg hover:bg-[#3E5F44] transition"
      >
        {formData.role === 'VENDOR' ? 'Continue to Vendor Details' : 'Register'}
      </button>
    </div>
  );

  // Step 2: Vendor Details Form
  const renderVendorForm = () => (
    <div className="space-y-6">
      {/* Business Information */}
      <div>
        <h3 className="text-lg font-semibold text-[#3E5F44] mb-3 flex items-center">
          🏢 Business Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Company Name *</label>
            <input
              type="text"
              name="companyName"
              value={vendorData.companyName}
              onChange={handleVendorChange}
              required
              placeholder="Your company name"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Business Email *</label>
            <input
              type="email"
              name="businessEmail"
              value={vendorData.businessEmail}
              onChange={handleVendorChange}
              required
              placeholder="business@company.com"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Primary Contact *</label>
            <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
              <span className="px-3 text-[#4A9782]">📞</span>
              <input
                type="tel"
                name="primaryContactNumber"
                value={vendorData.primaryContactNumber}
                onChange={handleVendorChange}
                required
                placeholder="+1 (555) 123-4567"
                className="w-full p-2 bg-transparent focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Established Year</label>
            <input
              type="number"
              name="establishedYear"
              value={vendorData.establishedYear}
              onChange={handleVendorChange}
              placeholder="2020"
              min="1900"
              max={new Date().getFullYear()}
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-[#3E5F44] text-sm font-medium mb-1">Business Description</label>
          <textarea
            name="businessDescription"
            value={vendorData.businessDescription}
            onChange={handleVendorChange}
            placeholder="Describe your business and products..."
            rows="3"
            className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
          />
        </div>

        <div className="mt-4">
          <label className="block text-[#3E5F44] text-sm font-medium mb-1">Website URL</label>
          <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
            <span className="px-3 text-[#4A9782]">🌐</span>
            <input
              type="url"
              name="websiteUrl"
              value={vendorData.websiteUrl}
              onChange={handleVendorChange}
              placeholder="https://yourcompany.com"
              className="w-full p-2 bg-transparent focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Legal & Tax Information */}
      <div>
        <h3 className="text-lg font-semibold text-[#3E5F44] mb-3">📋 Legal & Tax Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Business Registration Number</label>
            <input
              type="text"
              name="businessRegistrationNumber"
              value={vendorData.businessRegistrationNumber}
              onChange={handleVendorChange}
              placeholder="REG123456789"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Business License Number</label>
            <input
              type="text"
              name="businessLicenseNumber"
              value={vendorData.businessLicenseNumber}
              onChange={handleVendorChange}
              placeholder="LIC123456789"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Tax ID / EIN</label>
            <input
              type="text"
              name="taxId"
              value={vendorData.taxId}
              onChange={handleVendorChange}
              placeholder="12-3456789"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Address Information */}
      <div>
        <h3 className="text-lg font-semibold text-[#3E5F44] mb-3 flex items-center">
          📍 Business Address
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Street Address 1 *</label>
            <input
              type="text"
              name="streetAddress1"
              value={vendorData.streetAddress1}
              onChange={handleVendorChange}
              required
              placeholder="123 Main Street"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[#3E5F44] text-sm font-medium mb-1">Street Address 2</label>
            <input
              type="text"
              name="streetAddress2"
              value={vendorData.streetAddress2}
              onChange={handleVendorChange}
              placeholder="Suite 100 (optional)"
              className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[#3E5F44] text-sm font-medium mb-1">City *</label>
              <input
                type="text"
                name="city"
                value={vendorData.city}
                onChange={handleVendorChange}
                required
                placeholder="New York"
                className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#3E5F44] text-sm font-medium mb-1">State *</label>
              <input
                type="text"
                name="state"
                value={vendorData.state}
                onChange={handleVendorChange}
                required
                placeholder="NY"
                className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#3E5F44] text-sm font-medium mb-1">Postal Code *</label>
              <input
                type="text"
                name="postalCode"
                value={vendorData.postalCode}
                onChange={handleVendorChange}
                required
                placeholder="10001"
                className="w-full p-2 border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus:ring-2 focus:ring-[#93DA97] focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <button
          type="button"
          onClick={goBack}
          className="flex-1 py-3 bg-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-400 transition"
        >
          Back
        </button>
        <button
          type="button"
          onClick={handleVendorSubmit}
          disabled={isSubmitting}
          className="flex-1 py-3 bg-[#4A9782] text-white font-semibold rounded-lg hover:bg-[#3E5F44] transition disabled:opacity-50"
        >
          {isSubmitting ? 'Registering...' : 'Complete Registration'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#A3DC9A] to-[#5E936C] flex items-center justify-center px-4 py-8">
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-2xl px-6 py-6">
        <div className="mb-6 text-center">
          <div className="relative flex justify-center items-center">
            <button
              onClick={goHome}
              className="absolute left-[-7px] top-[-5px] text-3xl cursor-pointer z-[9999] transition-transform duration-300 hover:scale-125"
              aria-label="home"
            > 🏠 </button>
            <h2 className="text-3xl font-bold text-[#3E5F44]">
              {currentStep === 1 ? 'Create Your Account' : 'Vendor Business Details'}
            </h2>
          </div>
          <p className="text-sm text-[#4A9782] mt-1">
            {currentStep === 1 
              ? 'Join the fun and order your favorite vegan snacks!' 
              : 'Tell us about your business to complete vendor registration'}
          </p>
          
          {/* Progress indicator for vendor registration */}
          {formData.role === 'VENDOR' && (
            <div className="flex justify-center mt-4">
              <div className="flex items-center space-x-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  currentStep >= 1 ? 'bg-[#4A9782] text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  1
                </div>
                <div className={`w-16 h-1 ${currentStep >= 2 ? 'bg-[#4A9782]' : 'bg-gray-300'}`}></div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  currentStep >= 2 ? 'bg-[#4A9782] text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  2
                </div>
              </div>
            </div>
          )}
        </div>

        {currentStep === 1 ? renderBasicForm() : renderVendorForm()}

        <PopUp message={success} type="success" onClose={() => setSuccess("")} />
        <PopUp message={error} type="error" onClose={() => setError("")} />

        {currentStep === 1 && (
          <div className="text-center mt-6">
            <button
              onClick={() => alert('Navigate to login page')}
              className="text-[#3E5F44] hover:text-[#1E4030] font-medium transition"
            >
              Already have an account? Login here
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Register;