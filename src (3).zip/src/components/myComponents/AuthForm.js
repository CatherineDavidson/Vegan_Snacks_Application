// src/components/AuthForm.js
import React from 'react';

const AuthForm = ({ isRegister = false }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-accent px-4">
      <div className="bg-white shadow-lg rounded-2xl w-full max-w-md p-8">
        <h2 className="text-3xl font-bold text-primary mb-6 text-center">
          {isRegister ? 'Create Account' : 'Welcome Back'}
        </h2>

        <form className="space-y-5">
          {isRegister && (
            <>
              <div>
                <label className="block text-lg text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Your full name"
                />
              </div>
              <div>
                <label className="block text-lg text-gray-700 mb-1">Username</label>
                <input
                  type="text"
                  className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Create a username"
                />
              </div>
            </>
          )}
          <div>
            <label className="block text-lg text-gray-700 mb-1">Email</label>
            <input
              type="email"
              className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="block text-lg text-gray-700 mb-1">Password</label>
            <input
              type="password"
              className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-primary text-white py-3 rounded-xl hover:bg-green-700 transition duration-300"
          >
            {isRegister ? 'Register' : 'Login'}
          </button>

          <p className="text-center text-sm text-gray-600 mt-3">
            {isRegister ? 'Already have an account?' : 'Don’t have an account?'}{' '}
            <a href={isRegister ? "/login" : "/register"} className="text-secondary font-semibold hover:underline">
              {isRegister ? 'Login' : 'Register'}
            </a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default AuthForm;
