import React, { useState } from 'react';
import { ShoppingCart, Heart, User, Package, Star, TrendingUp, Bell, Search, Filter } from 'lucide-react';

const VeganSnacksDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data
  const customerData = {
    name: 'Alex Chen',
    email: 'alex.chen@email.com',
    memberSince: 'March 2023',
    totalOrders: 24,
    totalSpent: 432.50,
    favoriteSnacks: 12,
    veganStreak: 156
  };

  const recentOrders = [
    {
      id: '#VG2024-001',
      date: '2024-08-10',
      items: 3,
      total: 24.99,
      status: 'delivered',
      products: ['Coconut Energy Balls', 'Kale Chips', 'Almond Butter Cookies']
    },
    {
      id: '#VG2024-002',
      date: '2024-08-05',
      items: 2,
      total: 18.50,
      status: 'shipped',
      products: ['Quinoa Protein Bars', 'Cashew Chocolate Bites']
    },
    {
      id: '#VG2024-003',
      date: '2024-07-28',
      items: 4,
      total: 31.75,
      status: 'delivered',
      products: ['Mixed Nuts Trail Mix', 'Banana Chips', 'Pea Protein Crisps', 'Date & Oat Squares']
    }
  ];

  const favoriteSnacks = [
    {
      id: 1,
      name: 'Coconut Energy Balls',
      brand: 'GreenBite',
      rating: 4.8,
      price: 8.99,
      image: '🥥',
      category: 'Energy Snacks'
    },
    {
      id: 2,
      name: 'Kale Chips Original',
      brand: 'CrunchGreen',
      rating: 4.6,
      price: 5.49,
      image: '🥬',
      category: 'Chips'
    },
    {
      id: 3,
      name: 'Almond Butter Cookies',
      brand: 'NuttyDelights',
      rating: 4.9,
      price: 12.99,
      image: '🍪',
      category: 'Cookies'
    },
    {
      id: 4,
      name: 'Quinoa Protein Bars',
      brand: 'VegaFuel',
      rating: 4.7,
      price: 15.99,
      image: '🌾',
      category: 'Protein Bars'
    }
  ];

  const recommendations = [
    {
      id: 5,
      name: 'Spirulina Smoothie Mix',
      brand: 'SuperGreens',
      rating: 4.5,
      price: 19.99,
      image: '🌿',
      category: 'Supplements'
    },
    {
      id: 6,
      name: 'Cacao Raw Nibs',
      brand: 'PureCacao',
      rating: 4.4,
      price: 14.99,
      image: '🍫',
      category: 'Raw Foods'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'delivered': return 'text-green-600 bg-green-100';
      case 'shipped': return 'text-blue-600 bg-blue-100';
      case 'processing': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const StatCard = ({ title, value, subtitle, icon: Icon, color }) => (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className={`text-2xl font-bold ${color} mt-1`}>{value}</p>
          {subtitle && <p className="text-gray-500 text-xs mt-1">{subtitle}</p>}
        </div>
        <div className={`${color} opacity-20`}>
          <Icon size={32} />
        </div>
      </div>
    </div>
  );

  const ProductCard = ({ product, showAddToCart = false }) => (
    <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="text-center mb-3">
        <div className="text-4xl mb-2">{product.image}</div>
        <h3 className="font-semibold text-gray-900 text-sm">{product.name}</h3>
        <p className="text-gray-500 text-xs">{product.brand}</p>
      </div>
      <div className="flex items-center justify-center mb-2">
        <Star className="text-yellow-400 fill-current w-3 h-3" />
        <span className="text-gray-600 text-xs ml-1">{product.rating}</span>
      </div>
      <p className="text-green-600 font-bold text-center">${product.price}</p>
      {showAddToCart && (
        <button className="w-full mt-3 bg-green-500 text-white py-2 px-3 rounded-lg text-xs font-medium hover:bg-green-600 transition-colors">
          Add to Cart
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-green-600">🌱 VeganBites</div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search snacks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <button className="relative p-2 text-gray-600 hover:text-gray-900">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">2</span>
              </button>
              <button className="relative p-2 text-gray-600 hover:text-gray-900">
                <ShoppingCart className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">3</span>
              </button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-green-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">{customerData.name}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview', icon: TrendingUp },
              { id: 'orders', label: 'My Orders', icon: Package },
              { id: 'favorites', label: 'Favorites', icon: Heart },
              { id: 'profile', label: 'Profile', icon: User }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center space-x-2 px-3 py-2 border-b-2 font-medium text-sm ${
                  activeTab === id
                    ? 'border-green-500 text-green-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Welcome Section */}
            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
              <h1 className="text-2xl font-bold mb-2">Welcome back, {customerData.name}! 🌱</h1>
              <p className="opacity-90">You've been on your vegan journey for {customerData.veganStreak} days straight!</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Total Orders"
                value={customerData.totalOrders}
                subtitle="Since joining"
                icon={Package}
                color="text-blue-600"
              />
              <StatCard
                title="Total Spent"
                value={`$${customerData.totalSpent}`}
                subtitle="On delicious snacks"
                icon={ShoppingCart}
                color="text-green-600"
              />
              <StatCard
                title="Favorite Snacks"
                value={customerData.favoriteSnacks}
                subtitle="In your collection"
                icon={Heart}
                color="text-red-600"
              />
              <StatCard
                title="Vegan Streak"
                value={`${customerData.veganStreak} days`}
                subtitle="Keep it going!"
                icon={TrendingUp}
                color="text-purple-600"
              />
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recent Orders</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {recentOrders.slice(0, 3).map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4">
                          <div>
                            <p className="font-medium text-gray-900">{order.id}</p>
                            <p className="text-sm text-gray-500">{order.date}</p>
                          </div>
                          <div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                              {order.status}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mt-2">{order.products.join(', ')}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">${order.total}</p>
                        <p className="text-sm text-gray-500">{order.items} items</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recommendations */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recommended for You</h2>
                <p className="text-gray-600 text-sm mt-1">Based on your preferences</p>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                  {recommendations.map((product) => (
                    <ProductCard key={product.id} product={product} showAddToCart={true} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-900">My Orders</h1>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
                <Filter className="w-4 h-4" />
                <span>Filter</span>
              </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="divide-y divide-gray-200">
                {recentOrders.map((order) => (
                  <div key={order.id} className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h3 className="font-semibold text-gray-900">{order.id}</h3>
                          <p className="text-sm text-gray-500">Ordered on {order.date}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                          {order.status}
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">${order.total}</p>
                        <p className="text-sm text-gray-500">{order.items} items</p>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                      <ul className="space-y-1">
                        {order.products.map((product, index) => (
                          <li key={index} className="text-sm text-gray-600">• {product}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex space-x-3 mt-4">
                      <button className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-medium hover:bg-green-600">
                        Reorder
                      </button>
                      <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200">
                        Track Order
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Favorites Tab */}
        {activeTab === 'favorites' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-900">My Favorites</h1>
              <p className="text-gray-600">{favoriteSnacks.length} favorite snacks</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {favoriteSnacks.map((product) => (
                <div key={product.id} className="relative">
                  <ProductCard product={product} showAddToCart={true} />
                  <button className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-sm">
                    <Heart className="w-4 h-4 text-red-500 fill-current" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Profile Settings</h1>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={customerData.name}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={customerData.email}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Member Since</label>
                    <input
                      type="text"
                      value={customerData.memberSince}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500"
                    />
                  </div>
                  <button className="w-full bg-green-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-600">
                    Update Profile
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Preferences</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Email Notifications</span>
                    <input type="checkbox" defaultChecked className="rounded text-green-500 focus:ring-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">SMS Updates</span>
                    <input type="checkbox" className="rounded text-green-500 focus:ring-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Promotional Offers</span>
                    <input type="checkbox" defaultChecked className="rounded text-green-500 focus:ring-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">New Product Alerts</span>
                    <input type="checkbox" defaultChecked className="rounded text-green-500 focus:ring-green-500" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VeganSnacksDashboard;