import React, { useEffect, useState } from "react";
import api from "../../api";

export default function Cart() {
  const [cart, setCart] = useState(null);
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState(1);

  const load = async () => {
    const { data } = await api.get("/products/cart");
    setCart(data);
  };

  useEffect(() => { load(); }, []);

  const add = async () => {
    await api.post("/products/cart/items", { productId: Number(productId), quantity: Number(quantity) });
    load();
  };

  const removeItem = async (id) => {
    await api.delete(`/products/cart/items/${id}`);
    load();
  };

  const clear = async () => {
    await api.delete("/products/cart");
    load();
  };

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-xl shadow">
        <h3 className="font-semibold mb-2">Add to Cart</h3>
        <input className="border p-2 mr-2 rounded" placeholder="Product ID" value={productId} onChange={e=>setProductId(e.target.value)} />
        <input className="border p-2 mr-2 rounded" type="number" value={quantity} onChange={e=>setQuantity(e.target.value)} />
        <button onClick={add} className="px-3 py-2 bg-emerald-600 text-white rounded">Add</button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow">
        <h3 className="font-semibold mb-2">Your Cart</h3>
        {!cart ? "Loading..." : (
          <div>
            <ul className="divide-y">
              {cart.items?.map(it => (
                <li key={it.cartItemId} className="py-2 flex justify-between">
                  <span>Product #{it.product?.productId} • Qty: {it.quantity}</span>
                  <button onClick={()=>removeItem(it.cartItemId)} className="px-3 py-1 bg-rose-600 text-white rounded">Remove</button>
                </li>
              ))}
            </ul>
            <button onClick={clear} className="mt-3 px-3 py-2 bg-gray-700 text-white rounded">Clear</button>
          </div>
        )}
      </div>
    </div>
  );
}
