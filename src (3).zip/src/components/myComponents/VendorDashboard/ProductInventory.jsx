import React, { useEffect, useState } from "react";
import api from "../../api";

export default function ProductInventory({ productId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ quantity: 0, batchNumber: "", expiryDate: "" });

  const load = async () => {
    const { data } = await api.get(`/vendor/products/${productId}/inventory`);
    setItems(data);
  };

  useEffect(() => { load(); }, [productId]);

  const add = async () => {
    await api.post(`/vendor/products/${productId}/inventory`, form);
    setForm({ quantity: 0, batchNumber: "", expiryDate: "" });
    load();
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <input className="border p-2 rounded" type="number" placeholder="Qty" value={form.quantity} onChange={e=>setForm({...form, quantity:Number(e.target.value)})} />
        <input className="border p-2 rounded" placeholder="Batch" value={form.batchNumber} onChange={e=>setForm({...form, batchNumber:e.target.value})} />
        <input className="border p-2 rounded" type="date" value={form.expiryDate} onChange={e=>setForm({...form, expiryDate:e.target.value})} />
        <button onClick={add} className="px-3 py-2 bg-indigo-600 text-white rounded">Add</button>
      </div>

      <ul className="divide-y">
        {items.map(it => (
          <li key={it.inventoryId} className="py-2 text-sm">{it.batchNumber || "-"} • Qty: {it.quantity} • Exp: {it.expiryDate || "-"}</li>
        ))}
      </ul>
    </div>
  );
}
