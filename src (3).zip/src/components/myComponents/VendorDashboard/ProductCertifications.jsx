import React, { useEffect, useState } from "react";
import api from "../../api";

export default function ProductCertifications({ productId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ certificationName: "", issuingAuthority: "", issueDate: "", expiryDate: "" });

  const load = async () => {
    const { data } = await api.get(`/vendor/products/${productId}/certifications`);
    setItems(data);
  };

  useEffect(() => { load(); }, [productId]);

  const add = async () => {
    await api.post(`/vendor/products/${productId}/certifications`, form);
    setForm({ certificationName: "", issuingAuthority: "", issueDate: "", expiryDate: "" });
    load();
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <input className="border p-2 rounded" placeholder="Certification" value={form.certificationName} onChange={e=>setForm({...form, certificationName:e.target.value})} />
        <input className="border p-2 rounded" placeholder="Authority" value={form.issuingAuthority} onChange={e=>setForm({...form, issuingAuthority:e.target.value})} />
        <input className="border p-2 rounded" type="date" value={form.issueDate} onChange={e=>setForm({...form, issueDate:e.target.value})} />
        <input className="border p-2 rounded" type="date" value={form.expiryDate} onChange={e=>setForm({...form, expiryDate:e.target.value})} />
      </div>
      <button onClick={add} className="px-3 py-2 bg-indigo-600 text-white rounded">Add</button>

      <ul className="divide-y">
        {items.map(it => (
          <li key={it.certificationId} className="py-2 text-sm">{it.certificationName} • {it.issuingAuthority || "-"} • Exp: {it.expiryDate || "-"}</li>
        ))}
      </ul>
    </div>
  );
}
