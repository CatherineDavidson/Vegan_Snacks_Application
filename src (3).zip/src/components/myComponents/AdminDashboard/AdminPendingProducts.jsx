import React, { useEffect, useState } from "react";
import api from "../../api";

export default function AdminPendingProducts() {
  const [items, setItems] = useState([]);

  const load = async () => {
    // list approved is filtered server-side in controller; for demo keep endpoint /admin/products/pending
    const { data } = await api.get("/admin/products/pending");
    setItems(data);
  };

  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    await api.put(`/admin/products/${id}/status?status=${status}`);
    load();
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <h3 className="font-semibold mb-2">Pending Products</h3>
      <ul className="divide-y">
        {items.map(p => (
          <li key={p.productId} className="py-2 flex justify-between">
            <span>{p.name}</span>
            <div className="space-x-2">
              <button onClick={()=>setStatus(p.productId, "APPROVED")} className="px-3 py-1 bg-emerald-600 text-white rounded">Approve</button>
              <button onClick={()=>setStatus(p.productId, "REJECTED")} className="px-3 py-1 bg-rose-600 text-white rounded">Reject</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
