import { Moon, Sun, Sparkles } from "lucide-react";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  const[isDarkMode,setIsDarkMode] = useState(true);
  const[isMenuOpen,setIsMenuOpen] = useState(true);

  const themeClasses = {
    bg: {
      primary: isDarkMode ? 'bg-slate-900' : 'bg-gray-50',
      secondary: isDarkMode ? 'bg-slate-800' : 'bg-white',
      tertiary: isDarkMode ? 'bg-slate-700' : 'bg-gray-100',
      accent: isDarkMode ? 'bg-slate-800/50' : 'bg-gray-100/50'
    },
    text: {
      primary: isDarkMode ? 'text-white' : 'text-gray-900',
      secondary: isDarkMode ? 'text-slate-300' : 'text-gray-700',
      muted: isDarkMode ? 'text-slate-400' : 'text-gray-500'
    },
    border: {
      primary: isDarkMode ? 'border-slate-700' : 'border-gray-200',
      secondary: isDarkMode ? 'border-slate-600' : 'border-gray-300'
    },
    navbar: {
      bg: isDarkMode ? 'bg-slate-900/90' : 'bg-white/90'
    },
    button: {
      theme: isDarkMode 
        ? 'bg-slate-800 text-yellow-400 hover:bg-slate-700' 
        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
    },
    mobile: {
      bg: isDarkMode ? 'bg-slate-900/95' : 'bg-white/95'
    },
    heroBlobs: {
      violet: isDarkMode ? 'from-violet-500/20 to-purple-500/20' : 'from-violet-500/10 to-purple-500/10',
      cyan: isDarkMode ? 'from-cyan-500/20 to-blue-500/20' : 'from-cyan-500/10 to-blue-500/10',
      pink: isDarkMode ? 'from-pink-500/10 to-orange-500/10' : 'from-pink-500/5 to-orange-500/5'
    },
    badge: {
      bg: isDarkMode ? 'from-violet-500/20 to-purple-500/20' : 'from-violet-500/10 to-purple-500/10',
      border: isDarkMode ? 'border-violet-500/30' : 'border-violet-500/20',
      text: isDarkMode ? 'text-violet-300' : 'text-violet-700'
    },
    input: {
      placeholder: isDarkMode ? 'placeholder-slate-400' : 'placeholder-gray-500'
    }
  };

  const toggleTheme = () => setIsDarkMode(!isDarkMode);
    const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return(
    <div className={`min-h-screen transition-colors duration-300 ${themeClasses.bg.primary} ${themeClasses.text.primary}`}>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        `${themeClasses.navbar.bg} backdrop-blur-xl shadow-4xl ${themeClasses.border.primary}`
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand Name */}
            <div className="text-3xl font-bold bg-gradient-to-r from-violet-500 to-purple-500 bg-clip-text text-transparent cursor-pointer transform:Scale-105 transition-transform">
              Fresh<span className="text-cyan-400">Bites</span> 
            </div>

            <div className="flex items-center space-x-6">
              <button onClick={() => scrollToSection('features')} className={`${themeClasses.text.secondary} hover:text-cyan-400 font-medium transition-colors`}>
                Features
              </button>
              
              {/* Toggle Button */}
              <button
                onClick={toggleTheme}
                className={`p-2 rounded-full ${themeClasses.button.theme}`}
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              >
                {isDarkMode? <Sun size={20} /> : <Moon size={20} />}
              </button>

              <button
                onClick={() => {navigate('/login')}}
                className={`px-4 py-2 border border-cyan-400 text-cyan-400 rounded-full hover:bg-cyan-400 hover:text-white`}
              > Login </button>

              <button
                className={`px-4 py-2 bg-purple-500 text-white rounded-full hover:scale-105 transition-all duration 300 shadow-lg`}
                onClick={() => {navigate('/register')}}
              > Register </button>
            </div>
          </div>
        </div>
      </nav>

      <section id="hero" className="relative pt-24 pb-20 px-4 overflow-hidden">
         <div className="absolute inset-0">
          <div className={`absolute top-20 left-10 w-96 h-96 bg-gradient-to-r ${themeClasses.heroBlobs.violet} rounded-full blur-3xl animate-pulse`}></div>
          <div className={`absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-r ${themeClasses.heroBlobs.cyan} rounded-full blur-3xl animate-pulse delay-1000`}></div>
          <div className={`absolute top-1/2 left-1/2 w-72 h-72 bg-gradient-to-r ${themeClasses.heroBlobs.pink} rounded-full blur-3xl animate-pulse delay-2000`}></div>
        </div>
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
  
    
  <div className="w-full md:w-1/2 text-center md:text-left">
    <h1 className="text-6xl md:text-8xl font-bold mb-8 leading-tight">
      <span className="bg-gradient-to-r from-violet-400 via-violet-500 to-cyan-400 bg-clip-text text-transparent">
        Beyond
      </span>
      <br />
      <span className={themeClasses.text.primary}>the Bite</span>
    </h1>

    <p className={`text-xl md:text-2xl ${themeClasses.text.secondary} mb-12 max-w-4xl leading-relaxed`}>
      Experience the future of healthy eating with our scientifically crafted, 
      plant-based snacks that fuel your ambitions and satisfy your cravings.
    </p>
  </div>
  {/* right Side - SVG/Image */}
  <div className="w-full md:w-1/2 flex justify-center md:justify-start mb-8 md:mb-0">
    <img 
      src="E:\AppDevelopment\e0e4710a-b710-4761-b12d-09856463846a-31344db0-31f8-4f7a-935a-cbd8f2eab371\reactapp\src\components\images\snackGirl.png" 
      alt="Healthy Snacks" 
      className="w-80 h-auto"
    />
  </div>



</div>
      </section>

    </div>
  )
}
export default Home;