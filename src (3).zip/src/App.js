
// import './App.css';
// import Navbar from "./components/NavBar";

// import DisplayVeganSnacks from "./components/DisplayVeganSnacks";
// import ApplyForm from "./components/ApplyForm";
// import Footer from "./components/Footer";
// import Login from "./components/myComponents/Login";
// import CustomerDashboard from "./components/myComponents/CustomerDashboard";
// import Home from './components/myComponents/demogreen';
// import Demo from './components/myComponents/demo';
// import DemoG from './components/myComponents/demogreen';
// import VendorProfile from './components/myComponents/VendorDashboard/VendorProfile';
// import AdminDashboard from './components/myComponents/AdminDashboard/AdminDashboard';
// import Register from "./components/myComponents/Register";
// import AdminVendorApprovals from './components/myComponents/AdminDashboard/AdminVendorApprovals';
// import VendorApprovalDetail from './components/myComponents/AdminDashboard/VendorApprovalDetail';

// import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
// import { useNavigate } from "react-router-dom";

// const App = () => {
// function VendorApprovalsWrapper() {
//   const navigate = useNavigate();
//   return (
//     <AdminVendorApprovals onSelectVendor={(vendorId) => navigate(`/va?vendorId=${vendorId}`)} />
//   );
// }
//   return (
// <Router>
//       <Routes>
//         <Route path="/register" element={<Register />} />
//         <Route path="/" element={<Home />} />
//         <Route path="/demo" element={<Demo />} />
//         <Route path="/demo1" element={<DemoG />} />
//         <Route path="/login" element={<Login />} />
//         <Route path="/profile" element={<VendorProfile />} />
//         <Route path="/customer" element={<CustomerDashboard />} />
//         <Route path="/admin" element={<AdminDashboard />} />
//         <Route path="/av" element={<VendorApprovalsWrapper />} />
//         <Route path="/va/:vendorId" element={<VendorApprovalDetail />} />

//       </Routes>
//     </Router>
//   );
// }
// export default App;

import './App.css';
import Navbar from "./components/NavBar";
import Footer from "./components/Footer";

import DisplayVeganSnacks from "./components/DisplayVeganSnacks";
import ApplyForm from "./components/ApplyForm";
import Login from "./components/myComponents/Login";
import CustomerDashboard from "./components/myComponents/CustomerDashboard";
import Home from './components/myComponents/demogreen';
import Demo from './components/myComponents/demo';
import VendorProfile from './components/myComponents/VendorDashboard/VendorProfile';
import AdminDashboard from './components/myComponents/AdminDashboard/AdminDashboard';
import Register from "./components/myComponents/Register";
import AdminVendorApprovals from './components/myComponents/AdminDashboard/AdminVendorApprovals';
import VendorApprovalDetail from './components/myComponents/AdminDashboard/VendorApprovalDetail';
import AdminPendingProducts from './components/myComponents/AdminDashboard/AdminPendingProducts';

import { Route, Routes, BrowserRouter as Router, useNavigate } from 'react-router-dom';

const VendorApprovalsWrapper = () => {
  const navigate = useNavigate();
  return (
    <AdminVendorApprovals onSelectVendor={(vendorId) => navigate(`/va/${vendorId}`)} />
  );
};

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/demo" element={<Demo />} />
        <Route path="/display" element={<DisplayVeganSnacks />} />
        <Route path="/apply" element={<ApplyForm />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/profile" element={<VendorProfile />} />
        <Route path="/customer" element={<CustomerDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/av" element={<VendorApprovalsWrapper />} />
        <Route path="/pending" element={<AdminPendingProducts />} />
        <Route path="/va/:vendorId" element={<VendorApprovalDetail />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
