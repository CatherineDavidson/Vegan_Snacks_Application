import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import AdminVendorApproval from "./components/AdminVendorApproval";
import AdminDashboard from "./pages/AdminDashboard";
import VendorApprovalDetails from "./VendorApprovalDetails";
import VendorProfile from "./vendorProfile";
import Authform from "./components/Authform";
import DemoGreen from "./components/demoGreen";
import Popup from "./components/PopUp";
import VendorDashboard from "./VendorDashboard";
import ProductList from "./pages/ProductList";
import ProductDetail from "./pages/ProductDetail";
import CartPage from "./pages/CartPage";
import OrdersPage from "./pages/OrdersPage";
import CustomerDashboard from "./pages/CustomerDashboard";

export const handleLogout = (navigate) => {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  navigate("/"); // redirect to login page
};

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<DemoGreen />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/products" element={<ProductList />} />
        <Route path="/products/:id" element={<ProductDetail />} />
        <Route path="/cart/:userId" element={<CartPage />} />
        <Route path="/orders/:userId" element={<OrdersPage />} />

        {/* Unchanged key screens (placeholders if you don't replace them) */}
        <Route path="/admin/vendor-approvals" element={<AdminVendorApproval />} />
        <Route path="/admin/vendor-approvals/:vendorId" element={<VendorApprovalDetails />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/vendor/profile" element={<VendorProfile />} />
        <Route path="/vendor" element={<VendorDashboard />} />
        <Route path="/user" element={<CustomerDashboard />} />
        <Route path="/auth/form" element={<Authform />} />
        <Route path="/demo-green" element={<DemoGreen />} />
        <Route path="/popup" element={<Popup />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
