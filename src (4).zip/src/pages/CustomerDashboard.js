import { useState, useEffect } from 'react';
import { ShoppingCart, Search, Heart, Star, Plus, Minus, Moon, Sun, Filter, Eye, ShoppingBag, Zap, Award, Truck, Shield, ArrowRight, X } from 'lucide-react';

const CustomerDashboard = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [favorites, setFavorites] = useState(new Set());
  const [showQuickView, setShowQuickView] = useState(null);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const products = [
    {
      id: 1,
      name: "Dragon Fruit Energy Bites",
      category: "energy",
      price: 24.99,
      originalPrice: 29.99,
      image: "https://images.unsplash.com/photo-1544047720-b7d39c2cd1de?w=500&h=500&fit=crop",
      rating: 4.9,
      reviews: 287,
      description: "Exotic dragon fruit and chia seed energy bites that fuel your adventures with natural superfoods.",
      badges: ["NEW", "SUPERFOOD"],
      nutrition: { calories: 95, protein: 4, carbs: 12, fat: 3 },
      ingredients: ["Organic Dragon Fruit", "Chia Seeds", "Dates", "Coconut"],
      bestSeller: true
    },
    {
      id: 2,
      name: "Midnight Cocoa Protein Bars",
      category: "protein",
      price: 32.99,
      image: "https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=500&h=500&fit=crop",
      rating: 4.8,
      reviews: 156,
      description: "Rich, decadent protein bars crafted with premium dark cacao and plant-based proteins.",
      badges: ["PROTEIN", "DARK CHOCOLATE"],
      nutrition: { calories: 220, protein: 18, carbs: 14, fat: 9 },
      ingredients: ["Pea Protein", "Dark Cacao", "Almond Butter", "Coconut Oil"],
      bestSeller: false
    },
    {
      id: 3,
      name: "Golden Turmeric Chips",
      category: "chips",
      price: 18.99,
      image: "https://images.unsplash.com/photo-1633436515315-61b04eb81e8e?w=500&h=500&fit=crop",
      rating: 4.7,
      reviews: 203,
      description: "Anti-inflammatory turmeric-spiced vegetable chips with a satisfying golden crunch.",
      badges: ["ANTI-INFLAMMATORY", "GOLDEN"],
      nutrition: { calories: 130, protein: 2, carbs: 18, fat: 6 },
      ingredients: ["Sweet Potato", "Turmeric", "Coconut Oil", "Sea Salt"],
      bestSeller: false
    },
    {
      id: 4,
      name: "Cosmic Berry Mix",
      category: "snacks",
      price: 21.99,
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=500&fit=crop",
      rating: 4.9,
      reviews: 344,
      description: "A stellar blend of freeze-dried berries and activated nuts for an out-of-this-world snack experience.",
      badges: ["ANTIOXIDANT", "COSMIC"],
      nutrition: { calories: 160, protein: 5, carbs: 15, fat: 8 },
      ingredients: ["Goji Berries", "Activated Almonds", "Blueberries", "Cashews"],
      bestSeller: true
    },
    {
      id: 5,
      name: "Zen Matcha Cookies",
      category: "treats",
      price: 26.99,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500&h=500&fit=crop",
      rating: 4.6,
      reviews: 128,
      description: "Mindfully crafted matcha cookies that bring zen to your snacking ritual.",
      badges: ["MATCHA", "MINDFUL"],
      nutrition: { calories: 85, protein: 2, carbs: 11, fat: 4 },
      ingredients: ["Ceremonial Matcha", "Oat Flour", "Coconut Sugar", "Tahini"],
      bestSeller: false
    },
    {
      id: 6,
      name: "Phoenix Spice Crackers",
      category: "chips",
      price: 19.99,
      originalPrice: 24.99,
      image: "https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=500&h=500&fit=crop",
      rating: 4.8,
      reviews: 189,
      description: "Fiery seed crackers with a perfect balance of heat and flavor that rises above ordinary snacks.",
      badges: ["SPICY", "SEEDS"],
      nutrition: { calories: 140, protein: 6, carbs: 12, fat: 8 },
      ingredients: ["Sunflower Seeds", "Chili Pepper", "Nutritional Yeast", "Flax Seeds"],
      bestSeller: true
    }
  ];

  const categories = [
    { id: 'all', name: 'All', icon: '✨', gradient: 'from-purple-500 to-pink-500' },
    { id: 'energy', name: 'Energy', icon: '⚡', gradient: 'from-yellow-400 to-orange-500' },
    { id: 'protein', name: 'Protein', icon: '💪', gradient: 'from-blue-500 to-purple-600' },
    { id: 'chips', name: 'Chips', icon: '🔥', gradient: 'from-red-500 to-pink-500' },
    { id: 'snacks', name: 'Snacks', icon: '🌟', gradient: 'from-green-400 to-blue-500' },
    { id: 'treats', name: 'Treats', icon: '🍃', gradient: 'from-emerald-400 to-cyan-400' }
  ];

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (product, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
  };

  const updateCartQuantity = (productId, newQuantity) => {
    if (newQuantity === 0) {
      setCartItems(prev => prev.filter(item => item.id !== productId));
    } else {
      setCartItems(prev => 
        prev.map(item => 
          item.id === productId ? { ...item, quantity: newQuantity } : item
        )
      );
    }
  };

  const toggleFavorite = (productId) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(productId)) {
        newFavorites.delete(productId);
      } else {
        newFavorites.add(productId);
      }
      return newFavorites;
    });
  };

  const getTotalItems = () => cartItems.reduce((total, item) => total + item.quantity, 0);
  const getTotalPrice = () => cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);

  const themeClasses = {
    bg: isDarkMode ? 'bg-gray-900' : 'bg-gradient-to-br from-slate-50 to-blue-50',
    cardBg: isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200',
    text: isDarkMode ? 'text-white' : 'text-gray-900',
    textSecondary: isDarkMode ? 'text-gray-300' : 'text-gray-600',
    headerBg: isDarkMode ? 'bg-gray-800/95 border-gray-700' : 'bg-white/95 border-gray-200',
    inputBg: isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${themeClasses.bg}`}>
      {/* Futuristic Header */}
      <header className={`sticky top-0 z-50 backdrop-blur-xl border-b transition-all duration-300 ${themeClasses.headerBg}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-2xl flex items-center justify-center shadow-lg transform rotate-12">
                  <span className="text-white font-bold text-xl transform -rotate-12">V</span>
                </div>
              </div>
              <div>
                <h1 className={`text-2xl font-black ${themeClasses.text}`}>VERDANT</h1>
                <p className={`text-xs ${themeClasses.textSecondary} tracking-wider`}>FUTURE OF SNACKING</p>
              </div>
            </div>

            {/* Search Bar */}
            <div className="hidden md:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <Search className={`absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 ${themeClasses.textSecondary}`} />
                <input
                  type="text"
                  placeholder="Discover your next favorite snack..."
                  className={`w-full pl-12 pr-4 py-3 rounded-2xl border focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all ${themeClasses.inputBg} ${themeClasses.text}`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleTheme}
                className={`p-3 rounded-xl transition-all hover:scale-110 ${isDarkMode ? 'bg-yellow-500 text-gray-900' : 'bg-gray-800 text-yellow-400'}`}
              >
                {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>
              
              <button
                onClick={() => setIsCartOpen(true)}
                className={`relative p-3 rounded-xl transition-all hover:scale-110 ${themeClasses.cardBg} border`}
              >
                <ShoppingBag className={`h-5 w-5 ${themeClasses.text}`} />
                {getTotalItems() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-gradient-to-r from-emerald-500 to-blue-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold animate-pulse">
                    {getTotalItems()}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/20 to-blue-600/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-full text-sm font-medium mb-6">
            <Zap className="h-4 w-4 mr-2" />
            Plant-Powered Innovation
          </div>
          
          <h1 className={`text-5xl md:text-7xl font-black mb-6 ${themeClasses.text}`}>
            Snack Like The
            <span className="bg-gradient-to-r from-emerald-500 to-blue-500 bg-clip-text text-transparent"> Future</span>
          </h1>
          
          <p className={`text-xl md:text-2xl mb-8 max-w-3xl mx-auto ${themeClasses.textSecondary}`}>
            Revolutionary plant-based snacks engineered for peak performance and extraordinary taste
          </p>

          <div className="flex flex-wrap justify-center gap-6 mb-12">
            <div className={`flex items-center px-4 py-2 rounded-full ${themeClasses.cardBg} border`}>
              <Award className="h-5 w-5 mr-2 text-emerald-500" />
              <span className={`text-sm ${themeClasses.text}`}>Award Winning</span>
            </div>
            <div className={`flex items-center px-4 py-2 rounded-full ${themeClasses.cardBg} border`}>
              <Shield className="h-5 w-5 mr-2 text-blue-500" />
              <span className={`text-sm ${themeClasses.text}`}>100% Plant-Based</span>
            </div>
            <div className={`flex items-center px-4 py-2 rounded-full ${themeClasses.cardBg} border`}>
              <Truck className="h-5 w-5 mr-2 text-purple-500" />
              <span className={`text-sm ${themeClasses.text}`}>Carbon Neutral Delivery</span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`group relative overflow-hidden px-6 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 ${
                  selectedCategory === category.id
                    ? `bg-gradient-to-r ${category.gradient} text-white shadow-2xl scale-105`
                    : `${themeClasses.cardBg} border ${themeClasses.text} hover:shadow-xl`
                }`}
              >
                <span className="text-xl mr-2">{category.icon}</span>
                <span>{category.name}</span>
                {selectedCategory === category.id && (
                  <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                )}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(product => (
              <div key={product.id} className={`group relative overflow-hidden rounded-3xl transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl ${themeClasses.cardBg} border`}>
                {/* Best Seller Badge */}
                {product.bestSeller && (
                  <div className="absolute top-4 left-4 z-10 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                    ⭐ BESTSELLER
                  </div>
                )}

                {/* Favorite Button */}
                <button
                  onClick={() => toggleFavorite(product.id)}
                  className={`absolute top-4 right-4 z-10 p-2 rounded-full backdrop-blur-sm transition-all hover:scale-110 ${
                    favorites.has(product.id)
                      ? 'bg-red-500 text-white'
                      : `${themeClasses.cardBg} ${themeClasses.text}`
                  }`}
                >
                  <Heart className="h-4 w-4" fill={favorites.has(product.id) ? 'currentColor' : 'none'} />
                </button>

                {/* Product Image */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Quick View Button */}
                  <button
                    onClick={() => setShowQuickView(product)}
                    className="absolute bottom-4 right-4 p-2 bg-white/90 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:scale-110"
                  >
                    <Eye className="h-4 w-4 text-gray-800" />
                  </button>
                </div>

                {/* Product Info */}
                <div className="p-6">
                  {/* Badges */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {product.badges.map(badge => (
                      <span key={badge} className="px-2 py-1 bg-gradient-to-r from-emerald-500 to-blue-500 text-white text-xs rounded-full font-medium">
                        {badge}
                      </span>
                    ))}
                  </div>

                  <h3 className={`text-xl font-bold mb-2 ${themeClasses.text}`}>{product.name}</h3>
                  <p className={`text-sm mb-4 ${themeClasses.textSecondary} line-clamp-2`}>{product.description}</p>

                  {/* Rating and Reviews */}
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                        />
                      ))}
                    </div>
                    <span className={`text-sm ${themeClasses.textSecondary}`}>({product.reviews})</span>
                  </div>

                  {/* Nutrition Quick Info */}
                  <div className={`flex justify-between text-xs mb-4 p-3 rounded-xl ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <div className="text-center">
                      <div className={`font-bold ${themeClasses.text}`}>{product.nutrition.calories}</div>
                      <div className={themeClasses.textSecondary}>Cal</div>
                    </div>
                    <div className="text-center">
                      <div className={`font-bold ${themeClasses.text}`}>{product.nutrition.protein}g</div>
                      <div className={themeClasses.textSecondary}>Protein</div>
                    </div>
                    <div className="text-center">
                      <div className={`font-bold ${themeClasses.text}`}>{product.nutrition.carbs}g</div>
                      <div className={themeClasses.textSecondary}>Carbs</div>
                    </div>
                  </div>

                  {/* Price and Add to Cart */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className={`text-2xl font-black ${themeClasses.text}`}>${product.price}</span>
                      {product.originalPrice && (
                        <span className={`text-sm line-through ml-2 ${themeClasses.textSecondary}`}>${product.originalPrice}</span>
                      )}
                    </div>
                    <button
                      onClick={() => addToCart(product)}
                      className="group px-6 py-3 bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-2xl font-semibold transition-all hover:shadow-lg hover:scale-105 active:scale-95"
                    >
                      <Plus className="h-4 w-4 inline mr-1 group-hover:rotate-90 transition-transform" />
                      Add
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick View Modal */}
      {showQuickView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className={`relative max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-3xl ${themeClasses.cardBg} border`}>
            <button
              onClick={() => setShowQuickView(null)}
              className={`absolute top-4 right-4 z-10 p-2 rounded-full ${themeClasses.cardBg} border`}
            >
              <X className={`h-5 w-5 ${themeClasses.text}`} />
            </button>

            <div className="grid md:grid-cols-2 gap-6 p-6">
              <div>
                <img
                  src={showQuickView.image}
                  alt={showQuickView.name}
                  className="w-full h-64 object-cover rounded-2xl"
                />
              </div>
              <div>
                <h3 className={`text-2xl font-bold mb-4 ${themeClasses.text}`}>{showQuickView.name}</h3>
                <p className={`mb-4 ${themeClasses.textSecondary}`}>{showQuickView.description}</p>
                
                <div className="mb-4">
                  <h4 className={`font-semibold mb-2 ${themeClasses.text}`}>Ingredients:</h4>
                  <div className="flex flex-wrap gap-2">
                    {showQuickView.ingredients.map(ingredient => (
                      <span key={ingredient} className={`px-2 py-1 rounded-full text-xs ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} ${themeClasses.text}`}>
                        {ingredient}
                      </span>
                    ))}
                  </div>
                </div>

                <div className={`grid grid-cols-2 gap-4 p-4 rounded-xl mb-4 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="text-center">
                    <div className={`text-lg font-bold ${themeClasses.text}`}>{showQuickView.nutrition.calories}</div>
                    <div className={`text-sm ${themeClasses.textSecondary}`}>Calories</div>
                  </div>
                  <div className="text-center">
                    <div className={`text-lg font-bold ${themeClasses.text}`}>{showQuickView.nutrition.protein}g</div>
                    <div className={`text-sm ${themeClasses.textSecondary}`}>Protein</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className={`text-2xl font-black ${themeClasses.text}`}>${showQuickView.price}</span>
                  <button
                    onClick={() => {
                      addToCart(showQuickView);
                      setShowQuickView(null);
                    }}
                    className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-2xl font-semibold"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart Sidebar */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/50 backdrop-blur-sm" onClick={() => setIsCartOpen(false)}></div>
          <div className={`w-96 h-full overflow-y-auto ${themeClasses.cardBg} border-l`}>
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className={`text-xl font-bold ${themeClasses.text}`}>Your Cart</h3>
                <button onClick={() => setIsCartOpen(false)}>
                  <X className={`h-5 w-5 ${themeClasses.text}`} />
                </button>
              </div>
            </div>

            <div className="p-6">
              {cartItems.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className={`h-12 w-12 mx-auto mb-4 ${themeClasses.textSecondary}`} />
                  <p className={themeClasses.textSecondary}>Your cart is empty</p>
                </div>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {cartItems.map(item => (
                      <div key={item.id} className={`flex items-center space-x-4 p-4 rounded-xl ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-lg" />
                        <div className="flex-1">
                          <h4 className={`font-semibold ${themeClasses.text}`}>{item.name}</h4>
                          <p className={`text-sm ${themeClasses.textSecondary}`}>${item.price}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                            className={`p-1 rounded-full ${themeClasses.cardBg} border`}
                          >
                            <Minus className={`h-4 w-4 ${themeClasses.text}`} />
                          </button>
                          <span className={`w-8 text-center ${themeClasses.text}`}>{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                            className={`p-1 rounded-full ${themeClasses.cardBg} border`}
                          >
                            <Plus className={`h-4 w-4 ${themeClasses.text}`} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className={`border-t pt-4 ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <span className={`text-lg font-bold ${themeClasses.text}`}>Total: ${getTotalPrice()}</span>
                      <span className={`text-sm ${themeClasses.textSecondary}`}>{getTotalItems()} items</span>
                    </div>
                    <button className="w-full py-4 bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-2xl font-semibold flex items-center justify-center">
                      Checkout
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;