// import React, { useState } from "react";
// import {
//   BellIcon,
//   CheckBadgeIcon,
//   ClipboardDocumentListIcon,
//   UserGroupIcon,
// } from "@heroicons/react/24/outline";

// export default function AdminDashboard() {
//   const [activeTab, setActiveTab] = useState("requests");

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
//       {/* Navbar */}
//       <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-50">
//         <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
//           <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
//           <div className="flex items-center space-x-6">
//             <button className="relative">
//               <BellIcon className="w-6 h-6 text-gray-600" />
//               <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1.5 rounded-full">
//                 4
//               </span>
//             </button>
//             <img
//               src="https://i.pravatar.cc/40"
//               alt="Admin"
//               className="w-10 h-10 rounded-full border border-gray-300"
//             />
//           </div>
//         </div>
//       </header>

//       {/* Stats */}
//       <section className="max-w-7xl mx-auto px-6 py-6 grid grid-cols-1 md:grid-cols-4 gap-6">
//         <StatCard
//           icon={<UserGroupIcon className="w-8 h-8 text-indigo-600" />}
//           title="Total Vendors"
//           value="120"
//         />
//         <StatCard
//           icon={<ClipboardDocumentListIcon className="w-8 h-8 text-yellow-500" />}
//           title="Pending Requests"
//           value="8"
//         />
//         <StatCard
//           icon={<CheckBadgeIcon className="w-8 h-8 text-green-500" />}
//           title="Docs to Verify"
//           value="15"
//         />
//         <StatCard
//           icon={<BellIcon className="w-8 h-8 text-red-500" />}
//           title="Notifications"
//           value="4"
//         />
//       </section>

//       {/* Main Content */}
//       <main className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-6 pb-10">
//         {/* Left column: Requests + Verification */}
//         <div className="lg:col-span-2 space-y-6">
//           <TabSwitcher activeTab={activeTab} setActiveTab={setActiveTab} />
//           <div className="bg-white rounded-xl shadow p-4">
//             {activeTab === "requests" && (
//               <div>
//                 <h2 className="text-lg font-semibold mb-4">Vendor Requests</h2>
//                 <TablePlaceholder message="List of pending vendor requests" />
//               </div>
//             )}
//             {activeTab === "verify" && (
//               <div>
//                 <h2 className="text-lg font-semibold mb-4">
//                   Document Verification
//                 </h2>
//                 <TablePlaceholder message="Documents awaiting verification" />
//               </div>
//             )}
//           </div>
//         </div>

//         {/* Right column: Notifications */}
//         <div className="space-y-6">
//           <div className="bg-white rounded-xl shadow p-4">
//             <h2 className="text-lg font-semibold mb-4">Notifications</h2>
//             <ul className="space-y-3">
//               {["New vendor registered", "Document uploaded", "Vendor approved"].map(
//                 (note, idx) => (
//                   <li
//                     key={idx}
//                     className="p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition"
//                   >
//                     {note}
//                   </li>
//                 )
//               )}
//             </ul>
//           </div>
//         </div>
//       </main>
//     </div>
//   );
// }

// function StatCard({ icon, title, value }) {
//   return (
//     <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow hover:shadow-md transition flex items-center space-x-4">
//       <div className="p-3 bg-gray-100 rounded-lg">{icon}</div>
//       <div>
//         <p className="text-gray-500 text-sm">{title}</p>
//         <p className="text-2xl font-bold">{value}</p>
//       </div>
//     </div>
//   );
// }

// function TabSwitcher({ activeTab, setActiveTab }) {
//   return (
//     <div className="flex space-x-4 border-b border-gray-200">
//       {[
//         { key: "requests", label: "Requests" },
//         { key: "verify", label: "Verification" },
//       ].map((tab) => (
//         <button
//           key={tab.key}
//           className={`pb-2 px-2 ${
//             activeTab === tab.key
//               ? "border-b-2 border-indigo-600 text-indigo-600 font-medium"
//               : "text-gray-500 hover:text-indigo-600"
//           }`}
//           onClick={() => setActiveTab(tab.key)}
//         >
//           {tab.label}
//         </button>
//       ))}
//     </div>
//   );
// }

// function TablePlaceholder({ message }) {
//   return (
//     <div className="text-center text-gray-500 py-6 border-2 border-dashed border-gray-200 rounded-lg">
//       {message}
//     </div>
//   );
// }

import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Users, 
  Package, 
  ShoppingCart, 
  Shield, 
  Headphones,
  Settings,
  Home,
  Store,
  TrendingUp,
  Bell,
  Search,
  Sun,
  Moon,
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle,
  DollarSign,
  Activity,
  UserCheck,
  Package2,
  ArrowRight,
  Filter,
  Download,
  Tag,
  Grid3X3,
  Zap,
  Star,
  Clock
} from 'lucide-react';
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import AdminVendorApprovals from '../components/AdminVendorApproval';
import { handleLogout } from '../App';
import PopUp from '../components/PopUp';

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isDarkMode, setIsDarkMode] = useState(false);
  // const [error, setError] = useState("");
  // const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  // Theme classes
  const themeClasses = {
    bg: isDarkMode ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-200 via-indigo-200 to-purple-200',
    cardBg: isDarkMode ? 'bg-gray-800' : 'bg-white/70 backdrop-blur-sm',
    text: isDarkMode ? 'text-white' : 'text-gray-900',
    textSecondary: isDarkMode ? 'text-gray-300' : 'text-gray-600',
    border: isDarkMode ? 'border-gray-700' : 'border-white/20',
    hover: isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-white/50',
    navBg: isDarkMode ? 'bg-gray-800/95 backdrop-blur-md' : 'bg-white/80 backdrop-blur-md',
    tabActive: isDarkMode ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-blue-600 shadow-lg',
    tabInactive: isDarkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
  };

  // Sample data
  const stats = {
    totalUsers: 12847,
    totalVendors: 342,
    totalProducts: 1249,
    totalOrders: 8934,
    revenue: 284750,
    pendingApprovals: 23,
    categories: 18
  };

  const recentActivity = [
    { type: 'vendor', action: 'New vendor registered', name: 'Green Earth Foods', time: '2 min ago' },
    { type: 'product', action: 'Product approved', name: 'Organic Kale Chips', time: '5 min ago' },
    { type: 'order', action: 'Large order placed', name: '$2,450 order', time: '12 min ago' },
    { type: 'category', action: 'Category updated', name: 'Protein Bars', time: '15 min ago' },
    { type: 'user', action: 'New user registration', name: 'Sarah Johnson', time: '18 min ago' }
  ];

    const vendors = [
    { id: 1, name: "Green Earth Foods", owner: "John Smith", status: "Pending", products: 45 },
    { id: 2, name: "Nature's Delight", owner: "Priya Sharma", status: "Approved", products: 32 },
    { id: 3, name: "Vegan World", owner: "Alex Johnson", status: "Pending", products: 21 },
  ];

  const navigationTabs = [
    { 
      id: 'overview', 
      icon: Home, 
      label: 'Overview',
      gradient: 'from-blue-500 to-cyan-500',
      description: 'Dashboard & Analytics'
    },
    { 
      id: 'vendors', 
      icon: Store, 
      label: 'Vendors',
      gradient: 'from-emerald-500 to-green-500',
      description: 'Vendor Management',
      badge: 12
    },
    { 
      id: 'products', 
      icon: Package, 
      label: 'Products',
      gradient: 'from-purple-500 to-pink-500',
      description: 'Product Catalog',
      badge: 8
    },
    { 
      id: 'categories', 
      icon: Tag, 
      label: 'Categories',
      gradient: 'from-orange-500 to-red-500',
      description: 'Category Management'
    },
    { 
      id: 'users', 
      icon: Users, 
      label: 'Users',
      gradient: 'from-indigo-500 to-purple-500',
      description: 'User Accounts'
    },
    { 
      id: 'orders', 
      icon: ShoppingCart, 
      label: 'Orders',
      gradient: 'from-pink-500 to-rose-500',
      description: 'Order Processing',
      badge: 3
    },
    { 
      id: 'analytics', 
      icon: BarChart3, 
      label: 'Analytics',
      gradient: 'from-teal-500 to-cyan-500',
      description: 'Reports & Insights'
    },
    { 
      id: 'support', 
      icon: Headphones, 
      label: 'Support',
      gradient: 'from-violet-500 to-purple-500',
      description: 'Customer Service',
      badge: 7
    },
    { 
      id: 'settings', 
      icon: Settings, 
      label: 'Settings',
      gradient: 'from-gray-500 to-slate-500',
      description: 'System Config'
    }
  ];

  const quickActions = [
    { icon: UserCheck, label: 'Approve Vendors', count: 12, color: 'from-blue-500 to-blue-600' },
    { icon: Package2, label: 'Review Products', count: 8, color: 'from-green-500 to-green-600' },
    { icon: Tag, label: 'Manage Categories', count: 3, color: 'from-orange-500 to-orange-600' },
    { icon: Zap, label: 'Quick Actions', count: 5, color: 'from-purple-500 to-purple-600' }
  ];

const StatCard = ({ title, value, icon: Icon, trend, gradient, className = "" }) => (
  <div
    className={`rounded-3xl p-6 shadow-sm ${themeClasses.cardBg} ${themeClasses.border} border hover:shadow-xl transition-all duration-300 group relative overflow-hidden ${className}`}
  >
    <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}></div>
    <div className="relative flex items-center gap-4">
      <div className={`p-3 rounded-2xl bg-gradient-to-br ${gradient} text-white group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
        <Icon size={20} />
      </div>
      <div>
        <p className={`${themeClasses.textSecondary} text-sm font-medium mb-1`}>{title}</p>
        <p className={`text-3xl font-bold ${themeClasses.text}`}>
          {value !== undefined && value !== null ? value.toLocaleString() : "0"}
        </p>
      </div>
    </div>
  </div>
);



  const TabButton = ({ tab, isActive }) => (
    <button
      onClick={() => setActiveSection(tab.id)}
      className={`relative group px-6 py-4 rounded-2xl transition-all duration-300 transform hover:scale-105 border ${
        isActive ? themeClasses.tabActive : themeClasses.tabInactive
      }`}
    >
      <div className="flex items-center space-x-3">
        <div className={`p-2 rounded-lg transition-all duration-300 ${
          isActive 
            ? 'bg-white/20' 
            : `bg-gradient-to-br ${tab.gradient} text-white group-hover:scale-110`
        }`}>
          <tab.icon size={10} />
        </div>
        <div className="text-left">
          <div className="flex items-center space-x-2">
            <span className="font-semibold">{tab.label}</span>
            {/* {tab.badge && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
                {tab.badge}
              </span>
            )} */}
          </div>
        </div>
      </div>
    </button>
  );

  const QuickActionCard = ({ action }) => (
    <div className={`${themeClasses.cardBg} rounded-2xl p-6 ${themeClasses.border} border hover:shadow-lg transition-all duration-300 cursor-pointer group relative overflow-hidden`}>
      <div className={`absolute inset-0 bg-gradient-to-br ${action.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-xl bg-gradient-to-br ${action.color} text-white group-hover:scale-110 transition-transform duration-300`}>
            <action.icon size={20} />
          </div>
          <span className={`text-2xl font-bold ${themeClasses.text}`}>{action.count}</span>
        </div>
        <h4 className={`font-semibold ${themeClasses.text} mb-2`}>{action.label}</h4>
        <div className="flex items-center text-sm text-blue-600 group-hover:text-blue-700">
          <span>Take Action</span>
          <ArrowRight size={14} className="ml-1 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );

  const ActivityItem = ({ item }) => {
    const getIcon = () => {
      switch(item.type) {
        case 'vendor': return { icon: <Store size={16} />, color: 'text-blue-500' };
        case 'product': return { icon: <Package size={16} />, color: 'text-green-500' };
        case 'order': return { icon: <ShoppingCart size={16} />, color: 'text-purple-500' };
        case 'category': return { icon: <Tag size={16} />, color: 'text-orange-500' };
        case 'user': return { icon: <Users size={16} />, color: 'text-indigo-500' };
        default: return { icon: <Activity size={16} />, color: 'text-gray-500' };
      }
    };

    const iconData = getIcon();

    return (
      <div className={`flex items-center space-x-4 p-4 ${themeClasses.hover} rounded-xl transition-all duration-200 group`}>
        <div className={`p-3 rounded-full ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} group-hover:scale-110 transition-transform duration-200`}>
          <span className={iconData.color}>{iconData.icon}</span>
        </div>
        <div className="flex-1">
          <p className={`font-medium ${themeClasses.text} mb-1`}>{item.action}</p>
          <p className={`text-sm ${themeClasses.textSecondary}`}>{item.name}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Clock size={14} className={themeClasses.textSecondary} />
          <span className={`text-sm ${themeClasses.textSecondary}`}>{item.time}</span>
        </div>
      </div>
    );
  };

    const renderVendorsContent = () => (
    <div className="space-y-8">
      {/* Vendor Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Total Vendors" value={stats.totalVendors} icon={Store} trend={8} gradient="from-emerald-500 to-green-500" />
        <StatCard title="Pending Approvals" value={stats.pendingApprovals} icon={AlertTriangle} trend={-2} gradient="from-yellow-500 to-orange-500" />
        <StatCard title="Active Vendors" value={stats.totalVendors - stats.pendingApprovals} icon={UserCheck} trend={5} gradient="from-blue-500 to-cyan-500" />
      </div>

      {/* Vendor Management */}
      <div className={`${themeClasses.cardBg} rounded-3xl p-8 ${themeClasses.border} border shadow-sm`}>
        <AdminVendorApprovals/>
      </div>
    </div>
  );
  
const CategoriesDashboard = () => {
  const [stats, setStats] = useState({});
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [newCategory, setNewCategory] = useState({
    name: "",
    description: "",
  });


  // useEffect(() => {
  //   const fetchData = async () => {
  //     try {
  //       // Fetch summary
  //       // const summaryRes = await axios.get("/api/category/summary", {
  //       //     headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
  //       //   });
  //       // setStats(summaryRes.data);

  //       // Fetch all categories
  //       const categoryRes = await axios.get("/api/category/all", {
  //           headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
  //         });
  //       setCategories(categoryRes.data);

  //       setLoading(false);
  //     } catch (err) {
  //       console.error("Error fetching category data", err);
  //       setLoading(false);
  //     }
  //   };
  //   fetchData();
  // }, []);

  useEffect(() => {
  let ignore = false;

  const fetchData = async () => {
    try {
      const categoryRes = await axios.get("/api/category/all", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!ignore) {
        setCategories(categoryRes.data);
        setLoading(false);
      }
    } catch (err) {
      if (!ignore) {
        console.error("Error fetching category data", err);
        setLoading(false);
      }
    }
  };

  fetchData();

  return () => {
    ignore = true;  // cleanup prevents updating state on the fake 2nd run
  };
}, []);


  const handleCreateCategory = async () => {
  try {
    const response = await fetch("/api/category/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`, // if you use JWT
      },
      body: JSON.stringify(newCategory),
    });

    if (response.ok) {
      // setSuccess("Category created successfully!");
      setShowModal(false);
      setNewCategory({ name: "", description: "" });
      // fetchCategories(); 
    } else {
      // setError("Failed to create category.");
    }
  } catch (error) {
    console.error("Error creating category:", error);
  }
};


  // if (loading) return <p>Loading...</p>;

  return (
    <div className="space-y-8">
      {/* Big Box Container */}
      <div>
        <div className="grid grid-cols-5 gap-8">
          {/* Left Section: Stat Cards (1/5 width) */}
          <div className="col-span-1 space-y-4">
            <StatCard
              title="Total Categories"
              value={stats.totalCategories}
              icon={Tag}
              trend={5}
              gradient="from-orange-500 to-red-500"
            />
            <StatCard
              title="Active Products"
              value={stats.totalProducts ?? 0}
              icon={Package}
              trend={12}
              gradient="from-green-500 to-emerald-500"
            />
            <StatCard
              title="Top Category Sales"
              value={stats.topCategory?.noOfProducts ?? 0}
              icon={Star}
              trend={8}
              gradient="from-yellow-500 to-orange-500"
            />
            <StatCard
              title="New This Month"
              value={3}
              icon={Zap}
              trend={25}
              gradient="from-purple-500 to-pink-500"
            />
            <StatCard
              title="Pending Approvals"
              value={7}
              icon={AlertTriangle}
              trend={2}
              gradient="from-blue-500 to-indigo-500"
            />
          </div>

          {/* Right Section: Add Category (top) + Analysis (bottom) */}
          <div className="col-span-4 flex flex-col justify-between">
            {/* Add Category Section */}
            <div className="bg-white rounded-2xl p-6 mb-6 border border-gray-200">
              <h3 className="text-xl font-bold text-gray-800 mb-2">
                Category Management
              </h3>
              <p className="text-gray-500 mb-4">
                Organize and manage your product categories
              </p>
              <button
                onClick={() => setShowModal(true)}
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-xl hover:shadow-lg transition-all duration-300 font-medium"
              >
                Add Category
              </button>
            </div>

            {showModal && (
              <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                <div className="bg-white rounded-2xl p-6 w-96 shadow-lg">
                  <h2 className="text-xl font-bold mb-4 text-gray-800">Add New Category</h2>

                  <input
                    type="text"
                    placeholder="Category Name"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    className="w-full p-3 border rounded-lg mb-3 focus:ring-2 focus:ring-orange-500"
                  />

                  <textarea
                    placeholder="Description"
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                    className="w-full p-3 border rounded-lg mb-3 focus:ring-2 focus:ring-orange-500"
                  />

                  <div className="flex justify-end space-x-3">
                    <button
                      onClick={() => setShowModal(false)}
                      className="px-4 py-2 rounded-lg border hover:bg-gray-100"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateCategory}
                      className="px-4 py-2 rounded-lg bg-gradient-to-r from-orange-500 to-red-500 text-white hover:shadow-md"
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Placeholder Chart */}
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-800">Category Analysis</h3>
                <select className="text-sm border-2 border-gray-200 rounded-lg px-4 py-2">
                  <option>Last 7 days</option>
                  <option>Last 30 days</option>
                  <option>Last 3 months</option>
                </select>
              </div>
              <div className="h-64 flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                <div className="text-center">
                  <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500 font-medium">
                    Chart visualization would go here
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 border border-gray-200 hover:shadow-lg transition-all duration-300 group cursor-pointer"
          >
            <div
              className={`w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
            >
              <Tag className="text-white" size={20} />
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">
              {category.name}
            </h4>
            <p className="text-sm text-gray-500 mb-4">
              {category.noOfProducts} products
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">
                Active
              </span>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <Eye size={16} className="text-gray-400" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


  const renderContent = () => {
    if (activeSection === "vendors") return renderVendorsContent();

    if (activeSection === 'categories') return <CategoriesDashboard/>;

    if (activeSection === 'overview') {
      return (
        <div className="space-y-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7 gap-6">
            <StatCard title="Total Users" value={stats.totalUsers} icon={Users} trend={12} gradient="from-blue-500 to-cyan-500" />
            <StatCard title="Vendors" value={stats.totalVendors} icon={Store} trend={8} gradient="from-emerald-500 to-green-500" />
            <StatCard title="Products" value={stats.totalProducts} icon={Package} trend={15} gradient="from-purple-500 to-pink-500" />
            <StatCard title="Categories" value={stats.categories} icon={Tag} trend={5} gradient="from-orange-500 to-red-500" />
            <StatCard title="Orders" value={stats.totalOrders} icon={ShoppingCart} trend={22} gradient="from-pink-500 to-rose-500" />
            <StatCard title="Revenue" value={stats.revenue} icon={DollarSign} trend={18} gradient="from-teal-500 to-cyan-500" />
            <StatCard title="Pending" value={stats.pendingApprovals} icon={AlertTriangle} trend={-5} gradient="from-yellow-500 to-orange-500" />
          </div>

          {/* Quick Actions */}
          <div>
            <h3 className={`text-2xl font-bold ${themeClasses.text} mb-6`}>Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {quickActions.map((action, index) => (
                <QuickActionCard key={index} action={action} />
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className={`${themeClasses.cardBg} rounded-3xl p-8 ${themeClasses.border} border shadow-sm`}>
            <div className="flex items-center justify-between mb-6">
              <h3 className={`text-2xl font-bold ${themeClasses.text}`}>Recent Activity</h3>
              <button className="text-blue-600 hover:text-blue-700 font-medium flex items-center space-x-2 group">
                <span>View All</span>
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
            <div className="space-y-2">
              {recentActivity.map((item, index) => (
                <ActivityItem key={index} item={item} />
              ))}
            </div>
          </div>
        </div>
      );
    } else {
      const selectedTab = navigationTabs.find(t => t.id === activeSection);
      return (
        <div className={`${themeClasses.cardBg} rounded-3xl p-12 ${themeClasses.border} border shadow-sm text-center`}>
          <div className="max-w-lg mx-auto">
            <div className={`p-8 bg-gradient-to-br ${selectedTab?.gradient || 'from-gray-500 to-gray-600'} rounded-3xl w-32 h-32 mx-auto mb-8 flex items-center justify-center shadow-2xl`}>
              {selectedTab && <selectedTab.icon size={64} className="text-white" />}
            </div>
            <h3 className={`text-3xl font-bold ${themeClasses.text} mb-4`}>
              {selectedTab?.label}
            </h3>
            <p className={`${themeClasses.textSecondary} mb-8 text-lg leading-relaxed`}>
              {selectedTab?.description} module is under development. Complete functionality will be implemented based on your backend API endpoints.
            </p>
            <div className="space-y-4">
              <button 
                onClick={() => setActiveSection('overview')}
                className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-8 py-4 rounded-2xl hover:shadow-xl transition-all duration-300 font-semibold text-lg"
              >
                Back to Overview
              </button>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className={`min-h-screen ${themeClasses.bg} transition-all duration-500`}>
      {/* Header */}
      <div >
        <div className={`${themeClasses.navBg} ${themeClasses.border}shadow-2xl transition-all duration-300 mb-3`}>
          <div className="px-2 py-2">
            <div className="flex items-center justify-between mb-6">
              {/* Logo and Title */}
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Package className="text-white" size={20} />
                </div>
                <div>
                  <h1 className={`text-2xl font-bold ${themeClasses.text}`}>VeganSnacks</h1>
                  <p className={`${themeClasses.textSecondary}`}>Advanced Admin Control Center</p>
                </div>
              </div>
                
                <div className="relative text-2xl font-bold">
                  {activeSection || "Overview"}
                </div>

              {/* Right Controls */}
              <div className="flex items-center space-x-4">
                
                <button
                  onClick={toggleTheme}
                  className={`p-4 rounded-2xl ${themeClasses.hover} transition-all duration-300 group`}
                  title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                >
                  {isDarkMode ? (
                    <Sun className="text-yellow-500 group-hover:rotate-180 transition-transform duration-500" size={24} />
                  ) : (
                    <Moon className={`${themeClasses.textSecondary} group-hover:rotate-180 transition-transform duration-500`} size={24} />
                  )}
                </button>

                <button className={`p-4 ${themeClasses.hover} rounded-2xl transition-all duration-300 relative group`}>
                  <Bell className={`${themeClasses.textSecondary} group-hover:animate-bounce`} size={24} />
                  <span className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs rounded-full flex items-center justify-center font-bold animate-pulse">3</span>
                </button>

                <button
                  class="
                    relative inline-flex items-center justify-center px-4 py-2 font-medium text-white rounded-lg shadow-md
                    bg-gradient-to-r from-red-400 via-pink-500 to-purple-600
                    hover:from-red-500 hover:via-pink-600 hover:to-purple-700
                    transition-all duration-300
                    group
                    text-sm
                  " onClick={()=>handleLogout(navigate)}
                >
                  <span class="absolute inset-0 w-full h-full bg-white opacity-10 blur rounded-lg transition-all duration-300 group-hover:opacity-30"></span>

                  <span class="relative flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1m0-10V5m0 0H5m2 0h12" />
                    </svg>
                    Logout
                  </span>
                </button>

              </div>
            </div>
            

            {/* Navigation Tabs */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-hide">
              {navigationTabs.map((tab) => (
                <TabButton key={tab.id} tab={tab} isActive={activeSection === tab.id} />
              ))}
            </div>
            
          </div>
        </div>
      </div>
      {/* Popups */}
      {/* <PopUp message={success} type="success" onClose={() => setSuccess("")} />       
      <PopUp message={error} type="error" onClose={() => setError("")} /> */}

      {/* Main Content */}
      <main className="px-6 pb-12">
        <div className="max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;