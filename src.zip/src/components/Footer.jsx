import React from "react";

const Footer = () => {
    return(
        <footer>
            <p>/2024 Vegan Snacks Application. All rights reserved./i</p>
        </footer>
    )
};

export default Footer;