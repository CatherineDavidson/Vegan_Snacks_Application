import React from "react";
import {Link} from "react-router-dom";

const Home = () => {
    return (
        <div>
            <h1>Welcome to the Vegan Snacks App!</h1>
            <p>/Explore a delightful range of vegan snacks! Enjoy tasty, guilt-free treats made from natural ingredients./</p>
            <Link to = '/apply'>Add Your Vegan Snack</Link>
        </div>
    );
};

export default Home;