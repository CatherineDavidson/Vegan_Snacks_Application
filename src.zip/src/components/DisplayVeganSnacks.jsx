import React, { useEffect, useState } from "react";

const DisplayVeganSnacks = () => {

    const[snacks, setSnacks] = useState([]);
    useEffect(() => {
        fetch("http://localhost:8080/getAllVeganSnacks", {
            method : "GET",
            headers : {
                "Content-Type": "application/json",
            },
        })
        .then((res)=>res.json())
        .then((data)=>setSnacks(data))
        .then((error)=>console.error("Error fetching snacks",error))
    },[]);

    return (
        <div>
            <h2>Submitted Vegan Snacks</h2>
            <table>
                <thead>
                    <tr>
                        <th>Snack Name</th>
                        <th>Snack Type</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Expiry (in Months)</th>
                    </tr>
                </thead>
                <tbody>
                    {snacks.map((snack,index) => (
                        <tr key={index}>
                            <td>{snack.snackName}</td>
                            <td>{snack.snackType}</td>
                            <td>{snack.quantity}</td>
                            <td>{`Rs.${snack.price}`}</td>
                            <td>{snack.expiryInMonths}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
};

export default DisplayVeganSnacks;