import React from "react";
import {Link} from "react-router-dom";

const NavBar = () => {
    return(
        <nav>
            <h2>Vegan Snacks Application</h2>
            <ul>
                <li><Link className = "nav-link" to="/">Home</Link></li>
                <li><Link className = "nav-link" to="/apply">Apply</Link></li>
                <li><Link className = "nav-link" to="/getAllVeganSnacks">Snacks Details</Link></li>
            </ul>
        </nav>
    );
};

export default NavBar;