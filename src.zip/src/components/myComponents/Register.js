import React, { useState, useEffect, useRef } from "react";
import { registerUser } from "../../services/authService";
import { useNavigate } from 'react-router-dom';
import PopUp from '../PopUp';
import { FiUser, FiMail, FiLock, FiEye, FiEyeOff } from "react-icons/fi";

const roles = [
  { label: "Customer", value: "CUSTOMER", icon: "👤" },
  { label: "Vendor", value: "VENDOR", icon: "🛍️" },
  { label: "Product Manager", value: "PRODUCT_MANAGER", icon: "📦" },
];

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    userName: '',
    email: '',
    password: '',
    role: ''
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef();
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      const response = await registerUser(formData);
      setSuccess(`${response} Redirecting to login...`);

      setTimeout(() => {
        setSuccess("");
        navigate('/login');
      }, 3000);
    } catch (err) {
      setError(err.message || "Registration failed");

      setTimeout(() => {
        setError("");
      }, 4000);
    }
  };

  const handleRoleSelect = (role) => {
    setFormData(prev => ({ ...prev, role: role.value }));
    setIsDropdownOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#A3DC9A] to-[#5E936C] flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg w-4/5 max-w-md px-6 py-4">
        <div className="mb-4 text-center">
           <div className="relative flex justify-center items-center">
            <button
              onClick={() => navigate('/')}
              className="absolute left-[-7px] top-[-5px] text-3xl cursor-pointer z-[9999] transition-transform duration-300 hover:scale-125"
              aria-label="home"
            > 🏠 </button>
            <h2 className="text-3xl font-bold text-[#3E5F44]">Create Your Account</h2>
          </div>
          <p className="text-sm text-[#4A9782] mt-1">Join the fun and order your favorite vegan snacks!</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[#3E5F44] text-base font-semibold mb-1">Username</label>
            <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
              <span className="px-3 text-[#4A9782]"><FiUser /></span>
              <input
                type="text"
                name="userName"
                value={formData.userName}
                onChange={handleChange}
                required
                placeholder="Choose a username"
                className="w-full p-3 bg-transparent focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#3E5F44] text-base font-semibold mb-1">Email</label>
            <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
              <span className="px-3 text-[#4A9782]"><FiMail /></span>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="Enter your email"
                className="w-full p-3 bg-transparent focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#3E5F44] text-base font-semibold mb-1">Password</label>
            <div className="flex items-center border border-[#A3DC9A] rounded-lg bg-[#E8FFD7] focus-within:ring-2 focus-within:ring-[#93DA97]">
              <span className="px-3 text-[#4A9782]"><FiLock /></span>
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="Create a password"
                className="w-full p-3 bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(prev => !prev)}
                className="px-3 text-[#4A9782] focus:outline-none"
              >
                {showPassword ? <FiEyeOff /> : <FiEye />}
              </button>
            </div>
          </div>

          {/* Role Dropdown */}
          <div ref={dropdownRef} className="relative">
            <label className="block text-base font-semibold text-[#3E5F44] mb-1">Role</label>
            <button
              type="button"
              onClick={() => setIsDropdownOpen(prev => !prev)}
              className="w-full flex justify-between items-center px-4 py-2 bg-[#E8FFD7] border border-[#A3DC9A] rounded-lg shadow-sm hover:shadow-md transition focus:outline-none"
            >
              <span className="text-[#3E5F44] font-medium">
                {formData.role
                  ? roles.find(r => r.value === formData.role).label
                  : "-- Select a Role --"}
              </span>
              <span className="text-[#4A9782]">&#9662;</span>
            </button>

            {isDropdownOpen && (
              <ul className="absolute z-10 mt-1 w-full bg-[#E8FFD7] border border-[#A3DC9A] rounded-lg shadow-md max-h-48 overflow-y-auto">
                {roles.map((role) => (
                  <li
                    key={role.value}
                    onClick={() => handleRoleSelect(role)}
                    className="flex justify-between items-center px-4 py-2 cursor-pointer hover:bg-[#D0F1C4] hover:shadow-md transition border-b border-[#D0F1C4] last:border-b-0"
                  >
                    <span className="text-[#3E5F44]">{role.icon} {role.label}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-[#4A9782] text-white font-semibold rounded-lg hover:bg-[#3E5F44] transition"
          >
            Register
          </button>
        </form>

        <PopUp message={success} type="success" onClose={() => setSuccess("")} />
        <PopUp message={error} type="error" onClose={() => setError("")} />

        <div className="text-center mt-6">
          <button
            onClick={() => navigate('/login')}
            className="text-[#3E5F44] hover:text-[#1E4030] font-medium transition"
          >
            Already have an account? Login here
          </button>
        </div>
      </div>
    </div>
  );
};

export default Register;
