
import './App.css';
import Navbar from "./components/NavBar";

import DisplayVeganSnacks from "./components/DisplayVeganSnacks";
import ApplyForm from "./components/ApplyForm";
import Footer from "./components/Footer";
import Login from "./components/myComponents/Login";
import CustomerDashboard from "./components/myComponents/CustomerDashboard";
import Home from './components/myComponents/demogreen';
import Demo from './components/myComponents/demo';
import DemoG from './components/myComponents/demogreen';
import Register from "./components/myComponents/Register";

import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';

function App() {
  return (
    <Router>
      <Routes>
        <Route path = "/register" element = {<Register/>}/>
        <Route path = "/" element = {<Home/>}/>
        <Route path = "/demo" element = {<Demo/>}/>
        <Route path = "/demo1" element = {<DemoG/>}/>
        <Route path = "/login" element = {<Login/>}/>
        <Route path = "/customer" element = {<CustomerDashboard/>}/>
      </Routes>
    </Router>
  );
}

export default App;
